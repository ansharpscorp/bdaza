# ==========================================================
# STEP 2: Incremental Subnet Aggregation (Normal + Hotline)
# ==========================================================

from pyspark.sql import functions as F
from delta.tables import DeltaTable
from datetime import datetime, timezone, timedelta

DB = "default"

SRC_NORMAL  = f"{DB}.tblGold_EndpointFact"
SRC_HOTLINE = f"{DB}.tblGold_EndpointFact_Hotline"

TBL_AGG_NORMAL  = f"{DB}.tblGold_Agg_Subnet_5m"
TBL_AGG_HOTLINE = f"{DB}.tblGold_Agg_Subnet_5m_Hotline"

TBL_TRACKER = f"{DB}.tblGold_LoadTracker"

LATE_BUFFER_MIN = 30

# ----------------------------------------------------------
# Ensure target tables exist
# ----------------------------------------------------------
def ensure_agg_table(table_name):

    if not spark._jsparkSession.catalog().tableExists(table_name):
        spark.sql(f"""
        CREATE TABLE {table_name} (
            agg_id STRING,
            date STRING,
            bucket_end_time TIMESTAMP,
            receiver_subnet STRING,
            media_type STRING,

            call_count BIGINT,
            poor_call_count BIGINT,
            poor_rate DOUBLE,
            distinct_users BIGINT,

            avg_jitter DOUBLE,
            max_jitter DOUBLE,
            avg_packet_loss DOUBLE,
            avg_round_trip DOUBLE,

            inserted_at_utc TIMESTAMP,
            updated_at_utc TIMESTAMP
        )
        USING DELTA
        PARTITIONED BY (date)
        """)

ensure_agg_table(TBL_AGG_NORMAL)
ensure_agg_table(TBL_AGG_HOTLINE)

# ----------------------------------------------------------
# Get watermark
# ----------------------------------------------------------
def get_watermark(name):
    df = spark.table(TBL_TRACKER).where(F.col("table_name") == name)
    row = df.select("last_processed_end_time").head()
    return row["last_processed_end_time"] if row else None

wm = get_watermark("tblGold_EndpointFact")
if wm is None:
    wm = datetime.now(timezone.utc) - timedelta(days=1)

wm_buffer = wm - timedelta(minutes=LATE_BUFFER_MIN)

# ----------------------------------------------------------
# Aggregation function
# ----------------------------------------------------------
def build_subnet_agg(src_table):

    df = (spark.table(src_table)
          .where(F.col("end_time") > F.lit(wm_buffer))
          .where(F.col("receiver_subnet").isNotNull())
         )

    agg = (
        df.groupBy(
            "date",
            "bucket_end_time",
            "receiver_subnet",
            "media_type"
        )
        .agg(
            F.count("*").alias("call_count"),
            F.sum(F.coalesce("poor", F.lit(0))).alias("poor_call_count"),
            F.countDistinct("receiver_identity").alias("distinct_users"),
            F.avg("avg_jitter").alias("avg_jitter"),
            F.max("avg_jitter_max").alias("max_jitter"),
            F.avg("avg_packet_loss_rate").alias("avg_packet_loss"),
            F.avg("avg_round_trip").alias("avg_round_trip")
        )
        .withColumn(
            "poor_rate",
            F.when(F.col("call_count") > 0,
                   F.col("poor_call_count") / F.col("call_count"))
        )
    )

    agg = agg.withColumn(
        "agg_id",
        F.sha1(
            F.concat_ws("|",
                F.col("bucket_end_time").cast("string"),
                F.col("receiver_subnet"),
                F.col("media_type")
            )
        )
    )

    nowts = F.current_timestamp()

    agg = (agg
        .withColumn("inserted_at_utc", nowts)
        .withColumn("updated_at_utc", nowts)
    )

    return agg

# ----------------------------------------------------------
# Merge function
# ----------------------------------------------------------
def merge_agg(table_name, df):

    dt = DeltaTable.forName(spark, table_name)

    update_cols = [c for c in df.columns if c != "agg_id"]
    set_map = {c: f"s.{c}" for c in update_cols}
    insert_map = {c: f"s.{c}" for c in df.columns}

    (dt.alias("t")
     .merge(df.alias("s"), "t.agg_id = s.agg_id")
     .whenMatchedUpdate(set=set_map)
     .whenNotMatchedInsert(values=insert_map)
     .execute()
    )

# ----------------------------------------------------------
# Build + Merge Normal
# ----------------------------------------------------------
df_normal_agg = build_subnet_agg(SRC_NORMAL)
merge_agg(TBL_AGG_NORMAL, df_normal_agg)

# ----------------------------------------------------------
# Build + Merge Hotline
# ----------------------------------------------------------
df_hotline_agg = build_subnet_agg(SRC_HOTLINE)
merge_agg(TBL_AGG_HOTLINE, df_hotline_agg)

# ----------------------------------------------------------
# Update watermark
# ----------------------------------------------------------
max_end = spark.table(SRC_NORMAL).agg(F.max("end_time")).collect()[0][0]
if max_end:
    from delta.tables import DeltaTable
    dt = DeltaTable.forName(spark, TBL_TRACKER)

    src = spark.createDataFrame(
        [("tblGold_EndpointFact", max_end, datetime.now(timezone.utc))],
        "table_name string, last_processed_end_time timestamp, updated_at_utc timestamp"
    )

    (dt.alias("t")
      .merge(src.alias("s"), "t.table_name = s.table_name")
      .whenMatchedUpdate(set={
          "last_processed_end_time": "s.last_processed_end_time",
          "updated_at_utc": "s.updated_at_utc"
      })
      .execute()
    )

print("STEP 2 Complete")
