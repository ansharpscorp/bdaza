# ==========================================================
# STEP 5 – ANOMALY SCORING (Robust Z)
# ==========================================================

from pyspark.sql import functions as F
from delta.tables import DeltaTable
from datetime import datetime, timezone, timedelta

DB = "default"

EPSILON = 0.00001
Z_WARNING  = 3
Z_MAJOR    = 5
Z_CRITICAL = 8

MIN_CALLS = 5
MIN_USERS = 2

# ----------------------------------------------------------
# Generic anomaly builder
# ----------------------------------------------------------
def build_anomaly(
        agg_table,
        baseline_table,
        dim_col,
        dim_name,
        output_table):

    # Ensure output table exists
    if not spark._jsparkSession.catalog().tableExists(output_table):
        spark.sql(f"""
        CREATE TABLE {output_table} (
            anomaly_id STRING,
            date STRING,
            bucket_end_time TIMESTAMP,
            dimension_name STRING,
            dimension_value STRING,
            media_type STRING,

            call_count BIGINT,
            distinct_users BIGINT,
            poor_rate DOUBLE,
            avg_jitter DOUBLE,
            avg_packet_loss DOUBLE,
            avg_round_trip DOUBLE,

            z_poor_rate DOUBLE,
            z_jitter DOUBLE,
            z_packet_loss DOUBLE,
            z_round_trip DOUBLE,

            severity STRING,
            is_anomaly BOOLEAN,

            scored_at_utc TIMESTAMP
        )
        USING DELTA
        PARTITIONED BY (date)
        """)

    agg = spark.table(agg_table)

    agg = (agg
        .withColumn("dimension_name", F.lit(dim_name))
        .withColumnRenamed(dim_col, "dimension_value")
        .withColumn("dow", F.dayofweek("bucket_end_time"))
        .withColumn("hod", F.hour("bucket_end_time"))
    )

    baseline = spark.table(baseline_table)

    df = agg.join(
        baseline,
        on=[
            "dimension_name",
            "dimension_value",
            "media_type",
            "dow",
            "hod"
        ],
        how="left"
    )

    # Robust Z calculation
    df = (df
        .withColumn(
            "z_poor_rate",
            (F.col("poor_rate") - F.col("median_poor_rate")) /
            (1.4826 * F.col("mad_poor_rate") + EPSILON)
        )
        .withColumn(
            "z_jitter",
            (F.col("avg_jitter") - F.col("median_avg_jitter")) /
            (1.4826 * F.col("mad_avg_jitter") + EPSILON)
        )
        .withColumn(
            "z_packet_loss",
            (F.col("avg_packet_loss") - F.col("median_avg_packet_loss")) /
            (1.4826 * F.col("mad_avg_packet_loss") + EPSILON)
        )
        .withColumn(
            "z_round_trip",
            (F.col("avg_round_trip") - F.col("median_avg_round_trip")) /
            (1.4826 * F.col("mad_avg_round_trip") + EPSILON)
        )
    )

    # Take maximum absolute Z across metrics
    df = df.withColumn(
        "max_z",
        F.greatest(
            F.abs("z_poor_rate"),
            F.abs("z_jitter"),
            F.abs("z_packet_loss"),
            F.abs("z_round_trip")
        )
    )

    # Severity
    df = df.withColumn(
        "severity",
        F.when(F.col("max_z") >= Z_CRITICAL, "Critical")
         .when(F.col("max_z") >= Z_MAJOR, "Major")
         .when(F.col("max_z") >= Z_WARNING, "Warning")
         .otherwise("Normal")
    )

    df = df.withColumn(
        "is_anomaly",
        (F.col("severity") != "Normal") &
        (F.col("call_count") >= MIN_CALLS) &
        (F.col("distinct_users") >= MIN_USERS)
    )

    df = df.withColumn(
        "anomaly_id",
        F.sha1(
            F.concat_ws("|",
                F.col("bucket_end_time").cast("string"),
                F.col("dimension_name"),
                F.col("dimension_value"),
                F.col("media_type")
            )
        )
    )

    df = df.withColumn("scored_at_utc", F.current_timestamp())

    # Select final columns
    df_out = df.select(
        "anomaly_id",
        "date",
        "bucket_end_time",
        "dimension_name",
        "dimension_value",
        "media_type",
        "call_count",
        "distinct_users",
        "poor_rate",
        "avg_jitter",
        "avg_packet_loss",
        "avg_round_trip",
        "z_poor_rate",
        "z_jitter",
        "z_packet_loss",
        "z_round_trip",
        "severity",
        "is_anomaly",
        "scored_at_utc"
    )

    # MERGE
    dt = DeltaTable.forName(spark, output_table)

    update_cols = [c for c in df_out.columns if c != "anomaly_id"]
    set_map = {c: f"s.{c}" for c in update_cols}
    insert_map = {c: f"s.{c}" for c in df_out.columns}

    (dt.alias("t")
     .merge(df_out.alias("s"), "t.anomaly_id = s.anomaly_id")
     .whenMatchedUpdate(set=set_map)
     .whenNotMatchedInsert(values=insert_map)
     .execute()
    )

# ----------------------------------------------------------
# RUN FOR ALL 3 DIMENSIONS (Normal + Hotline)
# ----------------------------------------------------------

build_anomaly(
    "default.tblGold_Agg_Subnet_5m",
    "default.tblGold_Baseline_Subnet_5m",
    "receiver_subnet",
    "Subnet",
    "default.tblGold_Anomaly_Subnet_5m"
)

build_anomaly(
    "default.tblGold_Agg_User_5m",
    "default.tblGold_Baseline_User_5m",
    "receiver_identity",
    "User",
    "default.tblGold_Anomaly_User_5m"
)

build_anomaly(
    "default.tblGold_Agg_ExpressRoute_5m",
    "default.tblGold_Baseline_ExpressRoute_5m",
    "receiver_reflexive_ip",
    "ExpressRoute",
    "default.tblGold_Anomaly_ExpressRoute_5m"
)

print("STEP 5 Complete – Anomaly scoring done.")
