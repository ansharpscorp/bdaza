# ==========================================================
# STEP 6 – ALERT ENGINE (Persistence + Dedup)
# ==========================================================

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from delta.tables import DeltaTable

DB = "default"

ANOMALY_TABLES = [
    ("default.tblGold_Anomaly_Subnet_5m", "Subnet"),
    ("default.tblGold_Anomaly_User_5m", "User"),
    ("default.tblGold_Anomaly_ExpressRoute_5m", "ExpressRoute")
]

ALERT_TABLE = "default.tblGold_Alert_Outbox"

PERSIST_BUCKETS = 2  # consecutive buckets required

# ----------------------------------------------------------
# Create Alert Table if Not Exists
# ----------------------------------------------------------
if not spark._jsparkSession.catalog().tableExists(ALERT_TABLE):
    spark.sql(f"""
    CREATE TABLE {ALERT_TABLE} (
        alert_id STRING,
        dimension_name STRING,
        dimension_value STRING,
        media_type STRING,
        severity STRING,

        first_seen TIMESTAMP,
        last_seen TIMESTAMP,
        bucket_end_time TIMESTAMP,
        call_count BIGINT,
        distinct_users BIGINT,

        status STRING,
        created_at_utc TIMESTAMP,
        updated_at_utc TIMESTAMP
    )
    USING DELTA
    """)

# ----------------------------------------------------------
# Build Alert Logic
# ----------------------------------------------------------
def process_alerts(anomaly_table, dimension_name):

    df = spark.table(anomaly_table).where(F.col("is_anomaly") == True)

    # Order by dimension + media
    w = Window.partitionBy("dimension_value", "media_type") \
              .orderBy("bucket_end_time")

    # Check consecutive anomaly buckets
    df = df.withColumn("prev_bucket",
                       F.lag("bucket_end_time").over(w))

    df = df.withColumn(
        "is_consecutive",
        F.when(
            F.unix_timestamp("bucket_end_time") -
            F.unix_timestamp("prev_bucket") <= 300,  # 5 minutes
            1
        ).otherwise(0)
    )

    df = df.withColumn(
        "consecutive_count",
        F.sum("is_consecutive").over(w)
    )

    df = df.where(F.col("consecutive_count") >= (PERSIST_BUCKETS - 1))

    # Generate alert_id
    df = df.withColumn(
        "alert_id",
        F.sha1(
            F.concat_ws("|",
                F.col("dimension_name"),
                F.col("dimension_value"),
                F.col("media_type")
            )
        )
    )

    df = df.withColumn("status", F.lit("New"))
    df = df.withColumn("created_at_utc", F.current_timestamp())
    df = df.withColumn("updated_at_utc", F.current_timestamp())

    df_out = df.select(
        "alert_id",
        "dimension_name",
        "dimension_value",
        "media_type",
        "severity",
        F.col("bucket_end_time").alias("first_seen"),
        F.col("bucket_end_time").alias("last_seen"),
        "bucket_end_time",
        "call_count",
        "distinct_users",
        "status",
        "created_at_utc",
        "updated_at_utc"
    )

    # Merge into alert table
    dt = DeltaTable.forName(spark, ALERT_TABLE)

    (dt.alias("t")
     .merge(df_out.alias("s"), "t.alert_id = s.alert_id AND t.status != 'Resolved'")
     .whenMatchedUpdate(set={
         "last_seen": "s.last_seen",
         "bucket_end_time": "s.bucket_end_time",
         "call_count": "s.call_count",
         "distinct_users": "s.distinct_users",
         "severity": "s.severity",
         "updated_at_utc": "s.updated_at_utc",
         "status": "'Ongoing'"
     })
     .whenNotMatchedInsert(values={
         "alert_id": "s.alert_id",
         "dimension_name": "s.dimension_name",
         "dimension_value": "s.dimension_value",
         "media_type": "s.media_type",
         "severity": "s.severity",
         "first_seen": "s.first_seen",
         "last_seen": "s.last_seen",
         "bucket_end_time": "s.bucket_end_time",
         "call_count": "s.call_count",
         "distinct_users": "s.distinct_users",
         "status": "s.status",
         "created_at_utc": "s.created_at_utc",
         "updated_at_utc": "s.updated_at_utc"
     })
     .execute()
    )

# ----------------------------------------------------------
# Run for all anomaly tables
# ----------------------------------------------------------
for table_name, dim in ANOMALY_TABLES:
    process_alerts(table_name, dim)

print("STEP 6 Complete – Alerts generated.")
