# ==========================================================
# STEP 4: Baseline Statistical Layer (ALL 3 Dimensions)
# - Subnet, User, ExpressRoute
# - Normal + Hotline
# - Robust baseline: median + MAD by (dimension, media_type, dow, hod)
# Source tables:
#   tblGold_Agg_Subnet_5m, tblGold_Agg_Subnet_5m_Hotline
#   tblGold_Agg_User_5m,   tblGold_Agg_User_5m_Hotline
#   tblGold_Agg_ExpressRoute_5m, tblGold_Agg_ExpressRoute_5m_Hotline
# Output tables:
#   tblGold_Baseline_* (6 tables)
# ==========================================================

from pyspark.sql import functions as F
from delta.tables import DeltaTable
from datetime import datetime, timezone, timedelta

DB = "default"

# -------- Sources (Step 2/3 outputs) ----------
SRC_SUBNET_N   = f"{DB}.tblGold_Agg_Subnet_5m"
SRC_SUBNET_H   = f"{DB}.tblGold_Agg_Subnet_5m_Hotline"

SRC_USER_N     = f"{DB}.tblGold_Agg_User_5m"
SRC_USER_H     = f"{DB}.tblGold_Agg_User_5m_Hotline"

SRC_ER_N       = f"{DB}.tblGold_Agg_ExpressRoute_5m"
SRC_ER_H       = f"{DB}.tblGold_Agg_ExpressRoute_5m_Hotline"

# -------- Targets ----------
TGT_SUBNET_N   = f"{DB}.tblGold_Baseline_Subnet_5m"
TGT_SUBNET_H   = f"{DB}.tblGold_Baseline_Subnet_5m_Hotline"

TGT_USER_N     = f"{DB}.tblGold_Baseline_User_5m"
TGT_USER_H     = f"{DB}.tblGold_Baseline_User_5m_Hotline"

TGT_ER_N       = f"{DB}.tblGold_Baseline_ExpressRoute_5m"
TGT_ER_H       = f"{DB}.tblGold_Baseline_ExpressRoute_5m_Hotline"

# -------- Baseline window ----------
BASELINE_DAYS = 28          # robust weekly pattern coverage
MIN_SAMPLES   = 30          # minimum buckets needed to trust baseline (tune)
PCTL_ACCURACY = 2000        # percentile_approx accuracy (higher = more accurate, more compute)

def table_exists(full_name: str) -> bool:
    return spark._jsparkSession.catalog().tableExists(full_name)

def ensure_baseline_table(table_name: str, dim_col_name: str):
    if not table_exists(table_name):
        spark.sql(f"""
        CREATE TABLE {table_name} (
            baseline_id STRING,
            dimension_name STRING,
            dimension_value STRING,
            media_type STRING,
            dow INT,
            hod INT,

            n_samples BIGINT,

            median_poor_rate DOUBLE,
            mad_poor_rate DOUBLE,

            median_avg_jitter DOUBLE,
            mad_avg_jitter DOUBLE,

            median_avg_packet_loss DOUBLE,
            mad_avg_packet_loss DOUBLE,

            median_avg_round_trip DOUBLE,
            mad_avg_round_trip DOUBLE,

            baseline_window_days INT,
            computed_at_utc TIMESTAMP
        )
        USING DELTA
        """)

def build_baseline(src_table: str, dim_col: str, dim_name: str, tgt_table: str):
    ensure_baseline_table(tgt_table, dim_col)

    # Filter to last BASELINE_DAYS by bucket_end_time
    cutoff = datetime.now(timezone.utc) - timedelta(days=BASELINE_DAYS)

    df = (spark.table(src_table)
          .where(F.col("bucket_end_time") >= F.lit(cutoff).cast("timestamp"))
          .where(F.col(dim_col).isNotNull())
          .withColumnRenamed(dim_col, "dimension_value")
          .withColumn("dimension_name", F.lit(dim_name))
          .withColumn("dow", F.dayofweek("bucket_end_time").cast("int"))  # 1=Sun..7=Sat
          .withColumn("hod", F.hour("bucket_end_time").cast("int"))
         )

    # Metrics to baseline
    metrics = {
        "poor_rate": "median_poor_rate",
        "avg_jitter": "median_avg_jitter",
        "avg_packet_loss": "median_avg_packet_loss",
        "avg_round_trip": "median_avg_round_trip",
    }

    # ---- Pass 1: medians + sample count
    med_exprs = [F.count("*").alias("n_samples")]
    for m in metrics.keys():
        if m in df.columns:
            med_exprs.append(F.expr(f"percentile_approx({m}, 0.5, {PCTL_ACCURACY})").alias(metrics[m]))
        else:
            med_exprs.append(F.lit(None).cast("double").alias(metrics[m]))

    med = (df.groupBy("dimension_name", "dimension_value", "media_type", "dow", "hod")
             .agg(*med_exprs)
          )

    # ---- Pass 2: MAD = median(|x - median(x)|)
    # Join medians back, compute abs deviations, then compute median of those deviations
    joined = df.join(
        med.select("dimension_name","dimension_value","media_type","dow","hod", *metrics.values()),
        on=["dimension_name","dimension_value","media_type","dow","hod"],
        how="inner"
    )

    # Build deviation columns safely (if metric missing, deviation null)
    dev_cols = []
    if "poor_rate" in df.columns:
        dev_cols.append(F.abs(F.col("poor_rate") - F.col("median_poor_rate")).alias("dev_poor_rate"))
    else:
        dev_cols.append(F.lit(None).cast("double").alias("dev_poor_rate"))

    if "avg_jitter" in df.columns:
        dev_cols.append(F.abs(F.col("avg_jitter") - F.col("median_avg_jitter")).alias("dev_avg_jitter"))
    else:
        dev_cols.append(F.lit(None).cast("double").alias("dev_avg_jitter"))

    if "avg_packet_loss" in df.columns:
        dev_cols.append(F.abs(F.col("avg_packet_loss") - F.col("median_avg_packet_loss")).alias("dev_avg_packet_loss"))
    else:
        dev_cols.append(F.lit(None).cast("double").alias("dev_avg_packet_loss"))

    if "avg_round_trip" in df.columns:
        dev_cols.append(F.abs(F.col("avg_round_trip") - F.col("median_avg_round_trip")).alias("dev_avg_round_trip"))
    else:
        dev_cols.append(F.lit(None).cast("double").alias("dev_avg_round_trip"))

    dev = joined.select(
        "dimension_name","dimension_value","media_type","dow","hod", *dev_cols
    )

    mad = (dev.groupBy("dimension_name","dimension_value","media_type","dow","hod")
             .agg(
                 F.expr(f"percentile_approx(dev_poor_rate, 0.5, {PCTL_ACCURACY})").alias("mad_poor_rate"),
                 F.expr(f"percentile_approx(dev_avg_jitter, 0.5, {PCTL_ACCURACY})").alias("mad_avg_jitter"),
                 F.expr(f"percentile_approx(dev_avg_packet_loss, 0.5, {PCTL_ACCURACY})").alias("mad_avg_packet_loss"),
                 F.expr(f"percentile_approx(dev_avg_round_trip, 0.5, {PCTL_ACCURACY})").alias("mad_avg_round_trip"),
             )
          )

    baseline = (med.join(mad, on=["dimension_name","dimension_value","media_type","dow","hod"], how="left")
                  .where(F.col("n_samples") >= F.lit(MIN_SAMPLES))
                  .withColumn("baseline_window_days", F.lit(BASELINE_DAYS))
                  .withColumn("computed_at_utc", F.current_timestamp())
               )

    # Deterministic key
    baseline = baseline.withColumn(
        "baseline_id",
        F.sha1(F.concat_ws("|",
            F.col("dimension_name"),
            F.col("dimension_value"),
            F.col("media_type"),
            F.col("dow").cast("string"),
            F.col("hod").cast("string"),
            F.col("baseline_window_days").cast("string")
        ))
    )

    # MERGE into target (update baselines each run)
    ensure_baseline_table(tgt_table, dim_col)

    dt = DeltaTable.forName(spark, tgt_table)

    set_map = {c: f"s.{c}" for c in baseline.columns if c != "baseline_id"}
    insert_map = {c: f"s.{c}" for c in baseline.columns}

    (dt.alias("t")
      .merge(baseline.alias("s"), "t.baseline_id = s.baseline_id")
      .whenMatchedUpdate(set=set_map)
      .whenNotMatchedInsert(values=insert_map)
      .execute()
    )

# ================================
# RUN Step 4 for ALL three dims
# ================================

# Subnet
build_baseline(SRC_SUBNET_N, "receiver_subnet", "Subnet", TGT_SUBNET_N)
build_baseline(SRC_SUBNET_H, "receiver_subnet", "Subnet", TGT_SUBNET_H)

# User
build_baseline(SRC_USER_N, "receiver_identity", "User", TGT_USER_N)
build_baseline(SRC_USER_H, "receiver_identity", "User", TGT_USER_H)

# ExpressRoute / Reflexive IP
build_baseline(SRC_ER_N, "receiver_reflexive_ip", "ExpressRoute", TGT_ER_N)
build_baseline(SRC_ER_H, "receiver_reflexive_ip", "ExpressRoute", TGT_ER_H)

print("STEP 4 Complete: Baselines built for Subnet/User/ExpressRoute (Normal + Hotline).")
