# ==========================================================
# STEP 3 – USER + EXPRESSROUTE AGGREGATION (Incremental)
# ==========================================================

from pyspark.sql import functions as F
from delta.tables import DeltaTable
from datetime import datetime, timezone, timedelta

DB = "default"

SRC_NORMAL  = f"{DB}.tblGold_EndpointFact"
SRC_HOTLINE = f"{DB}.tblGold_EndpointFact_Hotline"

TBL_USER_NORMAL   = f"{DB}.tblGold_Agg_User_5m"
TBL_USER_HOTLINE  = f"{DB}.tblGold_Agg_User_5m_Hotline"

TBL_ER_NORMAL     = f"{DB}.tblGold_Agg_ExpressRoute_5m"
TBL_ER_HOTLINE    = f"{DB}.tblGold_Agg_ExpressRoute_5m_Hotline"

TBL_TRACKER       = f"{DB}.tblGold_LoadTracker"

LATE_BUFFER_MIN = 30

# ----------------------------------------------------------
# CREATE TABLE IF NOT EXISTS
# ----------------------------------------------------------
def ensure_table(table_name, dimension_col):

    if not spark._jsparkSession.catalog().tableExists(table_name):
        spark.sql(f"""
        CREATE TABLE {table_name} (
            agg_id STRING,
            date STRING,
            bucket_end_time TIMESTAMP,
            {dimension_col} STRING,
            media_type STRING,

            call_count BIGINT,
            poor_call_count BIGINT,
            poor_rate DOUBLE,
            distinct_users BIGINT,

            avg_jitter DOUBLE,
            max_jitter DOUBLE,
            avg_packet_loss DOUBLE,
            avg_round_trip DOUBLE,

            inserted_at_utc TIMESTAMP,
            updated_at_utc TIMESTAMP
        )
        USING DELTA
        PARTITIONED BY (date)
        """)

# Create all 4 tables
ensure_table(TBL_USER_NORMAL, "receiver_identity")
ensure_table(TBL_USER_HOTLINE, "receiver_identity")
ensure_table(TBL_ER_NORMAL, "receiver_reflexive_ip")
ensure_table(TBL_ER_HOTLINE, "receiver_reflexive_ip")

# ----------------------------------------------------------
# WATERMARK
# ----------------------------------------------------------
def get_watermark():
    df = spark.table(TBL_TRACKER).where(F.col("table_name") == "tblGold_EndpointFact")
    row = df.select("last_processed_end_time").head()
    return row["last_processed_end_time"] if row else None

wm = get_watermark()
if wm is None:
    wm = datetime.now(timezone.utc) - timedelta(days=1)

wm_buffer = wm - timedelta(minutes=LATE_BUFFER_MIN)

# ----------------------------------------------------------
# GENERIC AGG BUILDER
# ----------------------------------------------------------
def build_agg(src_table, dimension_column):

    df = (
        spark.table(src_table)
        .where(F.col("end_time") > F.lit(wm_buffer))
        .where(F.col(dimension_column).isNotNull())
    )

    agg = (
        df.groupBy(
            "date",
            "bucket_end_time",
            dimension_column,
            "media_type"
        )
        .agg(
            F.count("*").alias("call_count"),
            F.sum(F.coalesce("poor", F.lit(0))).alias("poor_call_count"),
            F.countDistinct("receiver_identity").alias("distinct_users"),
            F.avg("avg_jitter").alias("avg_jitter"),
            F.max("avg_jitter_max").alias("max_jitter"),
            F.avg("avg_packet_loss_rate").alias("avg_packet_loss"),
            F.avg("avg_round_trip").alias("avg_round_trip")
        )
        .withColumn(
            "poor_rate",
            F.when(F.col("call_count") > 0,
                   F.col("poor_call_count") / F.col("call_count"))
        )
    )

    agg = agg.withColumn(
        "agg_id",
        F.sha1(
            F.concat_ws("|",
                F.col("bucket_end_time").cast("string"),
                F.col(dimension_column),
                F.col("media_type")
            )
        )
    )

    nowts = F.current_timestamp()

    agg = (agg
        .withColumn("inserted_at_utc", nowts)
        .withColumn("updated_at_utc", nowts)
    )

    return agg

# ----------------------------------------------------------
# MERGE FUNCTION
# ----------------------------------------------------------
def merge_agg(table_name, df):

    dt = DeltaTable.forName(spark, table_name)

    update_cols = [c for c in df.columns if c != "agg_id"]
    set_map = {c: f"s.{c}" for c in update_cols}
    insert_map = {c: f"s.{c}" for c in df.columns}

    (dt.alias("t")
     .merge(df.alias("s"), "t.agg_id = s.agg_id")
     .whenMatchedUpdate(set=set_map)
     .whenNotMatchedInsert(values=insert_map)
     .execute()
    )

# ----------------------------------------------------------
# BUILD + MERGE USER AGGREGATES
# ----------------------------------------------------------
df_user_normal  = build_agg(SRC_NORMAL,  "receiver_identity")
df_user_hotline = build_agg(SRC_HOTLINE, "receiver_identity")

merge_agg(TBL_USER_NORMAL,  df_user_normal)
merge_agg(TBL_USER_HOTLINE, df_user_hotline)

# ----------------------------------------------------------
# BUILD + MERGE EXPRESS ROUTE AGGREGATES
# ----------------------------------------------------------
df_er_normal  = build_agg(SRC_NORMAL,  "receiver_reflexive_ip")
df_er_hotline = build_agg(SRC_HOTLINE, "receiver_reflexive_ip")

merge_agg(TBL_ER_NORMAL,  df_er_normal)
merge_agg(TBL_ER_HOTLINE, df_er_hotline)

print("STEP 3 Complete")
