from config import Config
from db import run_query, sql_quote

VALID_NETWORK_TYPES = {"all", "wired", "wifi", "mobilebb"}


def normalize_filters(args):
    lookback = args.get("lookback", "7")
    network_type = (args.get("network_type", "all") or "all").lower()
    building = args.get("building", "").strip()
    region = args.get("region", "").strip()
    severity_band = args.get("severity_band", "").strip()

    if lookback not in {"7", "30"}:
        lookback = "7"
    if network_type not in VALID_NETWORK_TYPES:
        network_type = "all"

    return {
        "lookback": int(lookback),
        "network_type": network_type,
        "building": building,
        "region": region,
        "severity_band": severity_band,
    }


def _incident_where(filters):
    clauses = [f"Date >= date_sub(current_date(), {filters['lookback']})"]
    if filters["network_type"] != "all":
        clauses.append(f"lower(ConnectionType) = {sql_quote(filters['network_type'])}")
    if filters["building"]:
        clauses.append(f"COALESCE(Subnet_Building, 'Unknown') = {sql_quote(filters['building'])}")
    if filters["region"]:
        clauses.append(f"COALESCE(ReflexiveIP_Region, 'Unknown') = {sql_quote(filters['region'])}")
    if filters["severity_band"]:
        clauses.append(f"COALESCE(SeverityBand, 'Unknown') = {sql_quote(filters['severity_band'])}")
    return " AND ".join(clauses)


def _call_detail_where(filters):
    clauses = [f"Date >= date_sub(current_date(), {filters['lookback']})"]
    if filters["network_type"] != "all":
        clauses.append(f"lower(ConnectionType) = {sql_quote(filters['network_type'])}")
    if filters["building"]:
        clauses.append(f"COALESCE(Subnet_Building, 'Unknown') = {sql_quote(filters['building'])}")
    if filters["region"]:
        clauses.append(f"COALESCE(ReflexiveIP_Region, 'Unknown') = {sql_quote(filters['region'])}")
    return " AND ".join(clauses)


def get_filter_options():
    q = f"""
    SELECT DISTINCT
      COALESCE(Subnet_Building, 'Unknown') AS building,
      COALESCE(ReflexiveIP_Region, 'Unknown') AS region,
      COALESCE(SeverityBand, 'Unknown') AS severity_band
    FROM {Config.TBL_INCIDENT}
    """
    df = run_query(q)
    return {
        "buildings": sorted(df["building"].dropna().unique().tolist()) if not df.empty else [],
        "regions": sorted(df["region"].dropna().unique().tolist()) if not df.empty else [],
        "severity_bands": sorted(df["severity_band"].dropna().unique().tolist()) if not df.empty else [],
    }


def get_kpis(filters):
    incident_where_sql = _incident_where(filters)
    call_where_sql = _call_detail_where(filters)
    q = f"""
    WITH incident_base AS (
      SELECT * FROM {Config.TBL_INCIDENT}
      WHERE {incident_where_sql}
    ),
    call_base AS (
      SELECT * FROM {Config.TBL_CALL_DETAIL}
      WHERE {call_where_sql}
    ),
    call_summary_base AS (
      SELECT * FROM {Config.TBL_CALL_SUMMARY}
      WHERE Date >= date_sub(current_date(), {filters['lookback']})
    )
    SELECT
      (SELECT COUNT(DISTINCT IncidentStreakId) FROM incident_base WHERE IsRealIncident = TRUE) AS real_incident_count,
      (SELECT COALESCE(SUM(IncidentHours), 0) FROM incident_base) AS incident_hours,
      (SELECT COALESCE(MAX(PeakAffectedUsers), 0) FROM incident_base) AS peak_affected_users,
      (SELECT COUNT(DISTINCT Call_Id) FROM call_base) AS distinct_calls,
      (SELECT COUNT(DISTINCT Session_Id) FROM call_base) AS distinct_sessions,
      (SELECT COALESCE(MAX(MaxSeverity), 0) FROM incident_base) AS max_severity,
      (SELECT COALESCE(MAX(Unique_User_Count), 0) FROM call_summary_base) AS max_call_participants
    """
    df = run_query(q)
    return df.iloc[0].to_dict() if not df.empty else {}


def get_worst_subnets(filters):
    where_sql = _incident_where(filters)
    q = f"""
    WITH agg AS (
      SELECT
        Subnet,
        COALESCE(Subnet_Building, 'Unknown') AS Subnet_Building,
        COALESCE(ReflexiveIP_Region, 'Unknown') AS ReflexiveIP_Region,
        COALESCE(ConnectionType, 'Unknown') AS ConnectionType,
        SUM(IncidentHours) AS IncidentHours,
        MAX(MaxSeverity) AS MaxSeverity,
        MAX(PeakAffectedUsers) AS PeakAffectedUsers,
        SUM(DistinctCallCount) AS DistinctCallCount,
        SUM(DistinctSessionCount) AS DistinctSessionCount
      FROM {Config.TBL_INCIDENT}
      WHERE {where_sql}
      GROUP BY Subnet, COALESCE(Subnet_Building, 'Unknown'), COALESCE(ReflexiveIP_Region, 'Unknown'), COALESCE(ConnectionType, 'Unknown')
    )
    SELECT *,
      (0.4 * COALESCE(MaxSeverity, 0) +
       0.3 * LEAST(COALESCE(PeakAffectedUsers, 0), 100) +
       0.2 * LEAST(COALESCE(IncidentHours, 0), 100) +
       0.1 * LEAST(COALESCE(DistinctCallCount, 0), 100)) AS ActionPriorityScore
    FROM agg
    ORDER BY ActionPriorityScore DESC, MaxSeverity DESC, PeakAffectedUsers DESC
    LIMIT 20
    """
    return run_query(q)


def get_alert_table(filters):
    incident_where_sql = _incident_where(filters)
    detail_where_sql = _call_detail_where(filters)
    q = f"""
    WITH incident_agg AS (
      SELECT
        Subnet,
        COALESCE(Subnet_Building, 'Unknown') AS Subnet_Building,
        COALESCE(ReflexiveIP_Region, 'Unknown') AS ReflexiveIP_Region,
        ConnectionType,
        MAX(MaxSeverity) AS MaxSeverity,
        SUM(IncidentHours) AS IncidentHours,
        MAX(PeakAffectedUsers) AS PeakAffectedUsers,
        MAX(Likely_Cause) AS Likely_Cause
      FROM {Config.TBL_INCIDENT}
      WHERE {incident_where_sql}
      GROUP BY Subnet, COALESCE(Subnet_Building, 'Unknown'), COALESCE(ReflexiveIP_Region, 'Unknown'), ConnectionType
    ),
    user_agg AS (
      SELECT
        Subnet,
        COUNT(DISTINCT Subject_Id) AS DistinctAffectedUsers,
        COUNT(DISTINCT Call_Id) AS DistinctCalls,
        COUNT(DISTINCT Session_Id) AS DistinctSessions
      FROM {Config.TBL_CALL_DETAIL}
      WHERE {detail_where_sql}
      GROUP BY Subnet
    )
    SELECT
      i.Subnet, i.Subnet_Building, i.ReflexiveIP_Region, i.ConnectionType,
      i.MaxSeverity, i.IncidentHours, i.PeakAffectedUsers,
      COALESCE(u.DistinctAffectedUsers, 0) AS DistinctAffectedUsers,
      COALESCE(u.DistinctCalls, 0) AS DistinctCalls,
      COALESCE(u.DistinctSessions, 0) AS DistinctSessions,
      i.Likely_Cause,
      CASE
        WHEN lower(i.ConnectionType) = 'wifi' THEN 'WiFi / LAN Team'
        WHEN lower(i.ConnectionType) = 'wired' THEN 'LAN / WAN Team'
        WHEN lower(i.ConnectionType) = 'mobilebb' THEN 'Carrier / Mobility Team'
        WHEN lower(i.Likely_Cause) LIKE '%pstn%' THEN 'Telephony / Voice Team'
        WHEN lower(i.Likely_Cause) LIKE '%vdi%' THEN 'VDI Team'
        ELSE 'Network Operations Team'
      END AS RecommendedOwnerTeam,
      CASE
        WHEN i.MaxSeverity >= 85 THEN 'Critical'
        WHEN i.MaxSeverity >= 70 THEN 'High'
        WHEN i.MaxSeverity >= 50 THEN 'Medium'
        ELSE 'Low'
      END AS AlertBand
    FROM incident_agg i
    LEFT JOIN user_agg u ON i.Subnet = u.Subnet
    ORDER BY
      CASE
        WHEN i.MaxSeverity >= 85 THEN 1
        WHEN i.MaxSeverity >= 70 THEN 2
        WHEN i.MaxSeverity >= 50 THEN 3
        ELSE 4
      END,
      DistinctAffectedUsers DESC,
      IncidentHours DESC
    LIMIT {Config.MAX_TABLE_ROWS}
    """
    return run_query(q)


def get_region_impact(filters):
    where_sql = _incident_where(filters)
    q = f"""
    SELECT
      COALESCE(ReflexiveIP_Region, 'Unknown') AS Region,
      SUM(IncidentHours) AS IncidentHours,
      MAX(PeakAffectedUsers) AS PeakAffectedUsers
    FROM {Config.TBL_INCIDENT}
    WHERE {where_sql}
    GROUP BY COALESCE(ReflexiveIP_Region, 'Unknown')
    ORDER BY IncidentHours DESC
    LIMIT 15
    """
    return run_query(q)


def get_trend(days: int, network_type: str = "all"):
    where = [f"Date >= date_sub(current_date(), {days})"]
    if network_type != "all":
        where.append(f"lower(ConnectionType) = {sql_quote(network_type)}")
    q = f"""
    SELECT
      Date,
      COUNT(DISTINCT IncidentStreakId) AS IncidentCount,
      SUM(IncidentHours) AS IncidentHours,
      MAX(PeakAffectedUsers) AS PeakAffectedUsers,
      AVG(MaxSeverity) AS AvgMaxSeverity
    FROM {Config.TBL_INCIDENT}
    WHERE {' AND '.join(where)}
    GROUP BY Date
    ORDER BY Date
    """
    return run_query(q)


def get_subnet_detail(subnet: str, lookback: int = 7):
    subnet_q = sql_quote(subnet)
    common_date_filter = f"Subnet = {subnet_q} AND Date >= date_sub(current_date(), {lookback})"

    kpi_q = f"""
    SELECT
      COUNT(DISTINCT IncidentStreakId) AS IncidentCount,
      SUM(IncidentHours) AS IncidentHours,
      MAX(MaxSeverity) AS MaxSeverity,
      MAX(PeakAffectedUsers) AS PeakAffectedUsers
    FROM {Config.TBL_INCIDENT}
    WHERE {common_date_filter}
    """

    trend_q = f"""
    SELECT Date,
      SUM(IncidentHours) AS IncidentHours,
      MAX(MaxSeverity) AS MaxSeverity,
      MAX(PeakAffectedUsers) AS PeakAffectedUsers
    FROM {Config.TBL_INCIDENT}
    WHERE {common_date_filter}
    GROUP BY Date
    ORDER BY Date
    """

    calls_q = f"""
    SELECT
      Date, Call_Id, Session_Id, Subject_UPN, Subject_Phone,
      First_UPN, Second_UPN, ConnectionType, ReflexiveIP,
      COALESCE(TRY_CAST(SeverityScore_Hourly AS DOUBLE), 0) AS SeverityScore_Hourly,
      Jitter_Max, RTT_Max, PLR_Max
    FROM {Config.TBL_CALL_DETAIL}
    WHERE {common_date_filter}
    ORDER BY Date DESC, COALESCE(TRY_CAST(SeverityScore_Hourly AS DOUBLE), 0) DESC
    LIMIT {Config.MAX_TABLE_ROWS}
    """

    impacted_users_q = f"""
    WITH incident_user_daily AS (
      SELECT
        d.Date,
        d.Subnet,
        COALESCE(d.Subject_UPN, d.Subject_Phone, 'Unknown') AS UserDisplay,
        COUNT(DISTINCT d.Call_Id) AS DistinctCalls,
        COUNT(DISTINCT d.Session_Id) AS DistinctSessions,
        MAX(COALESCE(TRY_CAST(d.SeverityScore_Hourly AS DOUBLE), 0)) AS DetailSeverity,
        MAX(COALESCE(i.MaxSeverity, 0)) AS IncidentSeverity
      FROM {Config.TBL_CALL_DETAIL} d
      LEFT JOIN {Config.TBL_INCIDENT} i
        ON d.Subnet = i.Subnet
       AND d.Date = i.Date
      WHERE d.{common_date_filter}
      GROUP BY d.Date, d.Subnet, COALESCE(d.Subject_UPN, d.Subject_Phone, 'Unknown')
    )
    SELECT
      UserDisplay,
      SUM(DistinctCalls) AS DistinctCalls,
      SUM(DistinctSessions) AS DistinctSessions,
      MAX(GREATEST(DetailSeverity, IncidentSeverity)) AS MaxSeverityScore
    FROM incident_user_daily
    GROUP BY UserDisplay
    ORDER BY MaxSeverityScore DESC, DistinctCalls DESC
    LIMIT {Config.MAX_TABLE_ROWS}
    """

    kpi_df = run_query(kpi_q)
    return {
        "kpis": kpi_df.iloc[0].to_dict() if not kpi_df.empty else {},
        "trend": run_query(trend_q),
        "calls": run_query(calls_q),
        "users": run_query(impacted_users_q),
    }
