import pandas as pd
from config import Config
from db import run_query, sql_quote

VALID_MODE = {"evaluate", "compare"}
VALID_NETWORK_TYPES = {"wired", "wifi", "mobilebb", "all"}
VALID_WINDOWS = {"7", "30", "custom"}
VALID_COMPARE_SCOPES = {"building", "region", "network_type"}


def normalize_insight_inputs(args):
    mode = (args.get("mode", "evaluate") or "evaluate").lower()
    network_type = (args.get("network_type", "all") or "all").lower()
    subnet = args.get("subnet", "").strip()
    window = (args.get("window", "7") or "7").lower()
    start_date = args.get("start_date", "").strip()
    end_date = args.get("end_date", "").strip()
    compare_scope = (args.get("compare_scope", "building") or "building").lower()

    if mode not in VALID_MODE:
        mode = "evaluate"
    if network_type not in VALID_NETWORK_TYPES:
        network_type = "all"
    if window not in VALID_WINDOWS:
        window = "7"
    if compare_scope not in VALID_COMPARE_SCOPES:
        compare_scope = "building"

    return {
        "mode": mode,
        "network_type": network_type,
        "subnet": subnet,
        "window": window,
        "start_date": start_date,
        "end_date": end_date,
        "compare_scope": compare_scope,
    }


def get_subnet_list(network_type="all"):
    where = []
    if network_type != "all":
        where.append(f"lower(ConnectionType) = {sql_quote(network_type)}")
    where_sql = f"WHERE {' AND '.join(where)}" if where else ""
    q = f"""
    SELECT DISTINCT Subnet
    FROM {Config.TBL_HOURLY}
    {where_sql}
    ORDER BY Subnet
    """
    df = run_query(q)
    return df["Subnet"].dropna().tolist() if not df.empty else []


def build_date_where(inp):
    if inp["window"] == "custom" and inp["start_date"] and inp["end_date"]:
        return f"Date BETWEEN {sql_quote(inp['start_date'])} AND {sql_quote(inp['end_date'])}"
    days = 7 if inp["window"] == "7" else 30
    return f"Date >= date_sub(current_date(), {days})"


def build_network_where(inp):
    if inp["network_type"] == "all":
        return ""
    return f" AND lower(ConnectionType) = {sql_quote(inp['network_type'])}"


def build_plain_english_query(inp):
    time_desc = {
        "7": "the last 7 days",
        "30": "the last 30 days",
        "custom": f"the date range from {inp['start_date']} to {inp['end_date']}",
    }[inp["window"]]

    subnet_desc = inp["subnet"] if inp["subnet"] else "[no subnet selected]"
    nt_desc = inp["network_type"].capitalize() if inp["network_type"] != "all" else "all network types"

    if inp["mode"] == "evaluate":
        return f"Evaluate subnet {subnet_desc} for {nt_desc} over {time_desc}. Focus on subnet-only severity, impact, and network quality trends."
    return f"Compare subnet {subnet_desc} against peer subnets in the same {inp['compare_scope']} for {nt_desc} over {time_desc}. Focus on peer gap, rank, and comparative impact."


def get_subnet_context(subnet):
    q = f"""
    SELECT
      Subnet,
      COALESCE(Subnet_Building, 'Unknown') AS Subnet_Building,
      COALESCE(ReflexiveIP_Region, 'Unknown') AS ReflexiveIP_Region,
      COALESCE(ConnectionType, 'Unknown') AS ConnectionType
    FROM {Config.TBL_INCIDENT}
    WHERE Subnet = {sql_quote(subnet)}
    LIMIT 1
    """
    df = run_query(q)
    return df.iloc[0].to_dict() if not df.empty else {}


def get_evidence_table(inp):
    if not inp["subnet"]:
        return pd.DataFrame()
    where_sql = build_date_where(inp)
    network_sql = build_network_where(inp)
    q = f"""
    SELECT Date, Subnet, IncidentHours, MaxSeverity, PeakAffectedUsers,
           DistinctCallCount, DistinctSessionCount, Likely_Cause
    FROM {Config.TBL_INCIDENT}
    WHERE Subnet = {sql_quote(inp['subnet'])}
      AND {where_sql}
      {network_sql}
    ORDER BY Date DESC, MaxSeverity DESC
    LIMIT {Config.MAX_TABLE_ROWS}
    """
    return run_query(q)


def get_selected_subnet_daily(inp):
    if not inp["subnet"]:
        return pd.DataFrame()
    where_sql = build_date_where(inp)
    network_sql = build_network_where(inp)
    q = f"""
    SELECT Date,
      AVG(SeverityScore) AS AvgSeverityScore,
      MAX(AffectedUsers) AS PeakAffectedUsers,
      AVG(Jitter_Avg) AS AvgJitter,
      AVG(RTT_Avg) AS AvgRTT,
      AVG(PLR_Avg) AS AvgPLR
    FROM {Config.TBL_HOURLY}
    WHERE Subnet = {sql_quote(inp['subnet'])}
      AND {where_sql}
      {network_sql}
    GROUP BY Date
    ORDER BY Date
    """
    return run_query(q)


def _peer_filter_clause(inp, context):
    clauses = [f"Subnet <> {sql_quote(inp['subnet'])}"]
    if inp["compare_scope"] == "building":
        clauses.append(f"COALESCE(Subnet_Building, 'Unknown') = {sql_quote(context.get('Subnet_Building', 'Unknown'))}")
    elif inp["compare_scope"] == "region":
        clauses.append(f"COALESCE(ReflexiveIP_Region, 'Unknown') = {sql_quote(context.get('ReflexiveIP_Region', 'Unknown'))}")
    elif inp["compare_scope"] == "network_type":
        clauses.append(f"lower(ConnectionType) = {sql_quote(str(context.get('ConnectionType', 'Unknown')).lower())}")
    return " AND ".join(clauses)


def get_peer_daily(inp):
    if not inp["subnet"] or inp["mode"] != "compare":
        return pd.DataFrame()
    context = get_subnet_context(inp["subnet"])
    if not context:
        return pd.DataFrame()
    where_sql = build_date_where(inp)
    network_sql = build_network_where(inp)
    peer_where_sql = _peer_filter_clause(inp, context)
    q = f"""
    SELECT Date,
      AVG(SeverityScore) AS PeerAvgSeverityScore,
      AVG(AffectedUsers) AS PeerAvgAffectedUsers,
      AVG(Jitter_Avg) AS PeerAvgJitter,
      AVG(RTT_Avg) AS PeerAvgRTT,
      AVG(PLR_Avg) AS PeerAvgPLR
    FROM {Config.TBL_HOURLY}
    WHERE {peer_where_sql}
      AND {where_sql}
      {network_sql}
    GROUP BY Date
    ORDER BY Date
    """
    return run_query(q)


def get_peer_ranking(inp):
    if not inp["subnet"] or inp["mode"] != "compare":
        return pd.DataFrame()
    context = get_subnet_context(inp["subnet"])
    if not context:
        return pd.DataFrame()
    where_sql = build_date_where(inp)
    network_sql = build_network_where(inp)
    peer_where_sql = _peer_filter_clause(inp, context)
    q = f"""
    SELECT Subnet,
      SUM(IncidentHours) AS IncidentHours,
      MAX(MaxSeverity) AS MaxSeverity,
      MAX(PeakAffectedUsers) AS PeakAffectedUsers
    FROM {Config.TBL_INCIDENT}
    WHERE {where_sql}
      {network_sql}
      AND {peer_where_sql}
    GROUP BY Subnet
    ORDER BY MaxSeverity DESC, IncidentHours DESC
    LIMIT 20
    """
    return run_query(q)


def generate_grounded_summary(inp, selected_df, peer_df, evidence_df):
    if selected_df is None or selected_df.empty:
        return {
            "executive_summary": "No subnet is selected or no data is available for the selected window.",
            "technical_summary": "",
            "recommended_action": "",
        }

    avg_severity = float(selected_df["AvgSeverityScore"].fillna(0).mean())
    avg_users = float(selected_df["PeakAffectedUsers"].fillna(0).mean())
    avg_jitter = float(selected_df["AvgJitter"].fillna(0).mean()) if "AvgJitter" in selected_df else 0.0
    avg_rtt = float(selected_df["AvgRTT"].fillna(0).mean()) if "AvgRTT" in selected_df else 0.0
    avg_plr = float(selected_df["AvgPLR"].fillna(0).mean()) if "AvgPLR" in selected_df else 0.0

    likely_cause = "Not enough data"
    if evidence_df is not None and not evidence_df.empty and "Likely_Cause" in evidence_df.columns:
        cause_counts = evidence_df["Likely_Cause"].fillna("Unknown").value_counts()
        if len(cause_counts):
            likely_cause = cause_counts.index[0]

    if inp["mode"] == "evaluate" or peer_df is None or peer_df.empty:
        recommended_action = "Review subnet-local conditions first. Validate repeated dates with the highest severity, affected users, jitter, RTT, and packet loss."
        if inp["network_type"] == "wifi":
            recommended_action = "Prioritize WiFi capacity, coverage, roaming, channel overlap, and interference checks for the selected subnet."
        elif inp["network_type"] == "wired":
            recommended_action = "Prioritize LAN/WAN path review, switch uplinks, QoS, packet drops, and routing checks for the selected subnet."
        elif inp["network_type"] == "mobilebb":
            recommended_action = "Prioritize carrier variability, signal quality, and repeated time-of-day congestion checks for the selected subnet."

        return {
            "executive_summary": (
                f"Subnet {inp['subnet']} has average severity {avg_severity:.1f} across the selected period, "
                f"with average peak affected users {avg_users:.1f}. This mode evaluates the subnet on its own rather than against peers."
            ),
            "technical_summary": (
                f"Average network quality indicators for the selected subnet are jitter {avg_jitter:.1f}, RTT {avg_rtt:.1f}, and packet loss {avg_plr:.2f}. "
                f"The most common likely cause in the evidence table is {likely_cause}."
            ),
            "recommended_action": recommended_action,
        }

    peer_avg_severity = float(peer_df["PeerAvgSeverityScore"].fillna(0).mean())
    peer_avg_users = float(peer_df["PeerAvgAffectedUsers"].fillna(0).mean())
    severity_gap = avg_severity - peer_avg_severity
    users_gap = avg_users - peer_avg_users

    if severity_gap > 10:
        gap_text = f"The selected subnet is materially worse than peers by {severity_gap:.1f} severity points."
    elif severity_gap > 3:
        gap_text = f"The selected subnet is somewhat worse than peers by {severity_gap:.1f} severity points."
    elif severity_gap < -3:
        gap_text = f"The selected subnet is performing better than peers by {abs(severity_gap):.1f} severity points."
    else:
        gap_text = "The selected subnet is broadly in line with peers on severity."

    return {
        "executive_summary": (
            f"Subnet {inp['subnet']} has average severity {avg_severity:.1f} versus peer average {peer_avg_severity:.1f}, "
            f"and average peak affected users {avg_users:.1f} versus peer average {peer_avg_users:.1f}. {gap_text}"
        ),
        "technical_summary": (
            f"Selected subnet averages are jitter {avg_jitter:.1f}, RTT {avg_rtt:.1f}, and packet loss {avg_plr:.2f}. "
            f"Average affected-user gap versus peers is {users_gap:.1f}. The most common likely cause is {likely_cause}."
        ),
        "recommended_action": (
            f"Use compare mode findings to validate whether the issue is subnet-local or part of a wider {inp['compare_scope']} pattern, "
            f"then prioritize the selected subnet if it remains consistently worse than peers."
        ),
    }
