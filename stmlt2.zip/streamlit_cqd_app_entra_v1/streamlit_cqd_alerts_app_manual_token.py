import json
from pathlib import Path
from datetime import date, timedelta
from typing import Any, Dict, List, Tuple

import pandas as pd
import requests
import streamlit as st
import matplotlib.pyplot as plt
from databricks import sql


def load_config(config_path: str = "config.json") -> Dict[str, Any]:
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with path.open("r", encoding="utf-8") as f:
        cfg = json.load(f)

    if "databricks" not in cfg:
        raise ValueError("Missing 'databricks' section in config.json")
    if "tables" not in cfg:
        raise ValueError("Missing 'tables' section in config.json")

    dbx = cfg["databricks"]
    required = [
        "server_hostname",
        "http_path",
        "tenant_id",
        "client_id",
        "client_secret",
        "scope"
    ]
    missing = [k for k in required if not dbx.get(k)]
    if missing:
        raise ValueError(f"Missing databricks config keys: {', '.join(missing)}")

    return cfg


CONFIG = load_config()
DBX = CONFIG["databricks"]
TABLES = CONFIG["tables"]
APP_CFG = CONFIG.get("app", {})

FACT_CALL_DETAILS = TABLES["call_details"]
FACT_INSIGHTS = TABLES["insights_hourly"]
ALERT_MASTER = TABLES["alert_master"]
ALERT_MONITOR = TABLES["alert_monitor_daily"]

APP_TITLE = APP_CFG.get("title", "CQD Drillthrough & Subnet Alerts")
DEFAULT_DAYS = int(APP_CFG.get("default_days", 7))
REQUEST_TIMEOUT = int(APP_CFG.get("request_timeout_seconds", 60))

st.set_page_config(page_title=APP_TITLE, layout="wide")


@st.cache_data(ttl=300, show_spinner=False)
def get_access_token() -> str:
    token_url = f"https://login.microsoftonline.com/{DBX['tenant_id']}/oauth2/v2.0/token"
    payload = {
        "grant_type": "client_credentials",
        "client_id": DBX["client_id"],
        "client_secret": DBX["client_secret"],
        "scope": DBX["scope"],
    }

    response = requests.post(token_url, data=payload, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()

    data = response.json()
    access_token = data.get("access_token")
    if not access_token:
        raise RuntimeError(f"Token endpoint did not return access_token. Response: {data}")
    return access_token


def get_connection():
    token = get_access_token()
    return sql.connect(
        server_hostname=DBX["server_hostname"],
        http_path=DBX["http_path"],
        access_token=token,
    )


@st.cache_data(ttl=300, show_spinner=False)
def run_query(query: str) -> pd.DataFrame:
    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query)
            rows = cursor.fetchall()
            cols = [desc[0] for desc in cursor.description]
    return pd.DataFrame(rows, columns=cols)


def quote_sql(value: str) -> str:
    return str(value).replace("'", "''")


def fmt_date(d: date) -> str:
    return d.strftime("%Y-%m-%d")


def parse_date_range(option: str) -> Tuple[date, date]:
    today = date.today()
    if option == "Last 7 Days":
        return today - timedelta(days=6), today
    if option == "Last 30 Days":
        return today - timedelta(days=29), today
    return today - timedelta(days=DEFAULT_DAYS - 1), today


def list_to_sql_in(values: List[str]) -> str:
    safe = [f"'{quote_sql(v)}'" for v in values]
    return "(" + ",".join(safe) + ")" if safe else "('')"


def selection_summary(
    mode: str,
    network_type: str,
    selected_subnets: List[str],
    time_choice: str,
    start_dt: date,
    end_dt: date,
) -> str:
    subnet_text = "all subnets"
    if selected_subnets:
        subnet_text = ", ".join(selected_subnets[:3])
        if len(selected_subnets) > 3:
            subnet_text += f" +{len(selected_subnets) - 3} more"

    time_text = f"from {fmt_date(start_dt)} to {fmt_date(end_dt)}" if time_choice == "Date Range" else time_choice.lower()
    return f"{mode} {network_type} for {subnet_text} {time_text}."


def severity_label_from_score(score: float) -> str:
    score = float(score or 0)
    if score >= 85:
        return "Critical"
    if score >= 70:
        return "High"
    if score >= 50:
        return "Medium"
    if score > 0:
        return "Low"
    return "None"


def build_where_clause(start_dt: date, end_dt: date, network_type: str, subnets: List[str]) -> str:
    clauses = [
        f"Date >= DATE('{fmt_date(start_dt)}')",
        f"Date <= DATE('{fmt_date(end_dt)}')",
    ]
    if network_type != "All":
        clauses.append(f"COALESCE(ConnectionType, 'Unknown') = '{quote_sql(network_type)}'")
    if subnets:
        clauses.append(f"CAST(Subnet AS STRING) IN {list_to_sql_in(subnets)}")
    return " AND ".join(clauses)


@st.cache_data(ttl=300, show_spinner=False)
def load_subnet_options(start_dt: date, end_dt: date, network_type: str) -> List[str]:
    extra = ""
    if network_type != "All":
        extra = f" AND COALESCE(ConnectionType, 'Unknown') = '{quote_sql(network_type)}' "
    query = f'''
    SELECT DISTINCT CAST(Subnet AS STRING) AS Subnet
    FROM {FACT_CALL_DETAILS}
    WHERE Date >= DATE('{fmt_date(start_dt)}')
      AND Date <= DATE('{fmt_date(end_dt)}')
      AND Subnet IS NOT NULL
      {extra}
    ORDER BY Subnet
    '''
    df = run_query(query)
    return df["Subnet"].dropna().astype(str).tolist() if not df.empty else []


@st.cache_data(ttl=300, show_spinner=False)
def load_kpis(start_dt: date, end_dt: date, network_type: str, subnets: List[str]) -> Dict[str, Any]:
    where_clause = build_where_clause(start_dt, end_dt, network_type, subnets)
    query = f'''
    WITH users_base AS (
        SELECT
            COALESCE(Subject_Id, Subject_Display_Id, Subject_UPN, Subject_Phone) AS user_key,
            Call_Id,
            Session_Id
        FROM {FACT_CALL_DETAILS}
        WHERE {where_clause}
    ),
    sev_base AS (
        SELECT MAX(COALESCE(SeverityScore, 0)) AS max_severity_score
        FROM {FACT_INSIGHTS}
        WHERE {where_clause}
    )
    SELECT
        COUNT(DISTINCT user_key) AS users_impacted,
        COUNT(DISTINCT Session_Id) AS sessions_impacted,
        COUNT(DISTINCT Call_Id) AS calls_impacted,
        COALESCE((SELECT max_severity_score FROM sev_base), 0) AS max_severity_score
    FROM users_base
    '''
    df = run_query(query)
    if df.empty:
        return {
            "users_impacted": 0,
            "sessions_impacted": 0,
            "calls_impacted": 0,
            "max_severity_score": 0.0,
            "max_severity_label": "None",
        }

    row = df.iloc[0].to_dict()
    row["max_severity_label"] = severity_label_from_score(float(row.get("max_severity_score") or 0.0))
    return row


@st.cache_data(ttl=300, show_spinner=False)
def load_daily_trend(start_dt: date, end_dt: date, network_type: str, subnets: List[str]) -> pd.DataFrame:
    where_clause = build_where_clause(start_dt, end_dt, network_type, subnets)
    query = f'''
    WITH user_day AS (
        SELECT
            Date,
            COUNT(DISTINCT COALESCE(Subject_Id, Subject_Display_Id, Subject_UPN, Subject_Phone)) AS impacted_users,
            COUNT(DISTINCT Session_Id) AS impacted_sessions,
            COUNT(DISTINCT Call_Id) AS impacted_calls
        FROM {FACT_CALL_DETAILS}
        WHERE {where_clause}
        GROUP BY Date
    ),
    metric_day AS (
        SELECT
            Date,
            MAX(COALESCE(SeverityScore, 0)) AS max_severity_score,
            AVG(COALESCE(RTT_Avg, 0)) AS avg_rtt,
            AVG(COALESCE(Jitter_Avg, 0)) AS avg_jitter,
            AVG(COALESCE(PLR_Avg, 0)) AS avg_packet_loss
        FROM {FACT_INSIGHTS}
        WHERE {where_clause}
        GROUP BY Date
    )
    SELECT
        u.Date,
        u.impacted_users,
        u.impacted_sessions,
        u.impacted_calls,
        COALESCE(m.max_severity_score, 0) AS max_severity_score,
        COALESCE(m.avg_rtt, 0) AS avg_rtt,
        COALESCE(m.avg_jitter, 0) AS avg_jitter,
        COALESCE(m.avg_packet_loss, 0) AS avg_packet_loss
    FROM user_day u
    LEFT JOIN metric_day m
      ON u.Date = m.Date
    ORDER BY u.Date
    '''
    return run_query(query)


@st.cache_data(ttl=300, show_spinner=False)
def load_user_drillthrough(start_dt: date, end_dt: date, network_type: str, subnets: List[str]) -> pd.DataFrame:
    where_clause = build_where_clause(start_dt, end_dt, network_type, subnets)
    query = f'''
    WITH cd_filtered AS (
        SELECT
            Date,
            HourBucket,
            Subnet,
            COALESCE(ConnectionType, 'Unknown') AS ConnectionType,
            COALESCE(Subject_UPN, Subject_Display_Id, Subject_Id, Subject_Phone, 'Unknown') AS user_id,
            Call_Id,
            Session_Id
        FROM {FACT_CALL_DETAILS}
        WHERE {where_clause}
    ),
    ih_filtered AS (
        SELECT
            Date,
            HourBucket,
            Subnet,
            COALESCE(ConnectionType, 'Unknown') AS ConnectionType,
            COALESCE(SeverityScore, 0) AS SeverityScore,
            COALESCE(RTT_Avg, 0) AS RTT_Avg,
            COALESCE(Jitter_Avg, 0) AS Jitter_Avg,
            COALESCE(PLR_Avg, 0) AS PLR_Avg
        FROM {FACT_INSIGHTS}
        WHERE {where_clause}
    ),
    severity_per_user AS (
        SELECT
            c.user_id,
            MAX(i.SeverityScore) AS max_severity_score,
            AVG(i.RTT_Avg) AS avg_rtt,
            AVG(i.Jitter_Avg) AS avg_jitter,
            AVG(i.PLR_Avg) AS avg_packet_loss
        FROM cd_filtered c
        LEFT JOIN ih_filtered i
          ON c.Date = i.Date
         AND COALESCE(c.HourBucket, CAST(c.Date AS TIMESTAMP)) = COALESCE(i.HourBucket, CAST(i.Date AS TIMESTAMP))
         AND COALESCE(c.Subnet, '') = COALESCE(i.Subnet, '')
         AND COALESCE(c.ConnectionType, 'Unknown') = COALESCE(i.ConnectionType, 'Unknown')
        GROUP BY c.user_id
    ),
    activity_per_user AS (
        SELECT
            user_id,
            COUNT(DISTINCT Session_Id) AS impacted_sessions,
            COUNT(DISTINCT Call_Id) AS impacted_calls
        FROM cd_filtered
        GROUP BY user_id
    )
    SELECT
        a.user_id AS User,
        CASE
            WHEN COALESCE(s.max_severity_score, 0) >= 85 THEN 'Critical'
            WHEN COALESCE(s.max_severity_score, 0) >= 70 THEN 'High'
            WHEN COALESCE(s.max_severity_score, 0) >= 50 THEN 'Medium'
            WHEN COALESCE(s.max_severity_score, 0) > 0 THEN 'Low'
            ELSE 'None'
        END AS Max_Severity,
        COALESCE(s.max_severity_score, 0) AS max_severity_score,
        a.impacted_sessions,
        a.impacted_calls,
        ROUND(COALESCE(s.avg_rtt, 0), 2) AS avg_rtt,
        ROUND(COALESCE(s.avg_jitter, 0), 2) AS avg_jitter,
        ROUND(COALESCE(s.avg_packet_loss, 0), 4) AS avg_packet_loss
    FROM activity_per_user a
    LEFT JOIN severity_per_user s
      ON a.user_id = s.user_id
    ORDER BY max_severity_score DESC, impacted_sessions DESC, impacted_calls DESC
    '''
    return run_query(query)


@st.cache_data(ttl=300, show_spinner=False)
def load_top_worst_subnets(start_dt: date, end_dt: date) -> pd.DataFrame:
    query = f'''
    SELECT
        subnet,
        connection_type,
        region,
        country,
        users_affected_7d,
        hours_affected_7d,
        max_severity_band,
        ROUND(avg_rtt_ms, 2) AS avg_rtt_ms,
        ROUND(avg_jitter_ms, 2) AS avg_jitter_ms,
        ROUND(avg_packet_loss_rate, 4) AS avg_packet_loss_rate,
        alert_score,
        ticket_status,
        ticket_id,
        run_date
    FROM {ALERT_MASTER}
    WHERE run_date >= DATE('{fmt_date(start_dt)}')
      AND run_date <= DATE('{fmt_date(end_dt)}')
    ORDER BY alert_score DESC, run_date DESC
    LIMIT 5
    '''
    return run_query(query)


@st.cache_data(ttl=300, show_spinner=False)
def load_open_tickets() -> pd.DataFrame:
    query = f'''
    SELECT
        alert_id,
        ticket_id,
        ticket_status,
        subnet,
        connection_type,
        region,
        country,
        run_date,
        monitoring_end_date,
        repeat_count,
        users_affected_7d,
        hours_affected_7d,
        max_severity_band,
        ROUND(avg_rtt_ms, 2) AS avg_rtt_ms,
        ROUND(avg_jitter_ms, 2) AS avg_jitter_ms,
        ROUND(avg_packet_loss_rate, 4) AS avg_packet_loss_rate,
        ticket_body
    FROM {ALERT_MASTER}
    WHERE is_active_monitoring = TRUE
      AND COALESCE(ticket_status, 'New') NOT IN ('Closed', 'Resolved', 'Monitoring Complete')
    ORDER BY
      CASE
        WHEN ticket_status = 'New' THEN 1
        WHEN ticket_status = 'In Progress' THEN 2
        WHEN ticket_status = 'Monitoring' THEN 3
        ELSE 4
      END,
      run_date DESC
    '''
    return run_query(query)


@st.cache_data(ttl=300, show_spinner=False)
def load_ticket_monitoring(alert_id: str) -> pd.DataFrame:
    query = f'''
    SELECT
        monitor_date,
        users_affected_day,
        calls_affected_day,
        sessions_affected_day,
        hours_affected_day,
        peak_issue_hour,
        max_severity_band_day,
        avg_rtt_ms_day,
        avg_jitter_ms_day,
        avg_packet_loss_rate_day,
        repeat_flag,
        improved_flag,
        worsened_flag,
        monitor_comment
    FROM {ALERT_MONITOR}
    WHERE alert_id = '{quote_sql(alert_id)}'
    ORDER BY monitor_date
    '''
    return run_query(query)


def render_line_chart(df: pd.DataFrame, x_col: str, y_col: str, title: str, y_label: str):
    if df.empty or x_col not in df.columns or y_col not in df.columns:
        st.info("No data available.")
        return

    plot_df = df.copy()
    plot_df[x_col] = pd.to_datetime(plot_df[x_col], errors="coerce")

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(plot_df[x_col], plot_df[y_col], marker="o")
    ax.set_title(title)
    ax.set_xlabel("Date")
    ax.set_ylabel(y_label)
    ax.grid(True, alpha=0.3)
    fig.autofmt_xdate()
    st.pyplot(fig)


def render_home():
    with st.sidebar:
        st.header("Filters")
        mode = st.radio("Mode", ["Evaluate", "Compare"], index=0)
        network_type = st.selectbox("Network Type", ["All", "Wired", "WiFi", "Unknown"], index=0)
        time_choice = st.radio("Time Range", ["Last 7 Days", "Last 30 Days", "Date Range"], index=0)

        if time_choice == "Date Range":
            default_start = date.today() - timedelta(days=6)
            default_end = date.today()
            start_dt = st.date_input("Start Date", value=default_start)
            end_dt = st.date_input("End Date", value=default_end)
        else:
            start_dt, end_dt = parse_date_range(time_choice)

        subnet_options = load_subnet_options(start_dt, end_dt, network_type)
        selected_subnets = st.multiselect("Subnet", options=subnet_options, default=[])

    st.subheader("Selection Summary")
    st.info(selection_summary(mode, network_type, selected_subnets, time_choice, start_dt, end_dt))

    kpis = load_kpis(start_dt, end_dt, network_type, selected_subnets)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Users Impacted", f"{int(kpis.get('users_impacted') or 0):,}")
    c2.metric("Sessions Impacted", f"{int(kpis.get('sessions_impacted') or 0):,}")
    c3.metric("Calls Impacted", f"{int(kpis.get('calls_impacted') or 0):,}")
    c4.metric("Max Severity", kpis.get("max_severity_label", "None"))

    trend_df = load_daily_trend(start_dt, end_dt, network_type, selected_subnets)
    left, right = st.columns([2, 1])

    with left:
        st.subheader("Trend")
        render_line_chart(trend_df, "Date", "impacted_sessions", "Impacted Sessions Trend", "Impacted Sessions")
        metric_choice = st.selectbox("Additional Trend Metric", ["avg_rtt", "avg_jitter", "avg_packet_loss"], index=0)
        render_line_chart(trend_df, "Date", metric_choice, f"{metric_choice} Trend", metric_choice)

    with right:
        st.subheader("Top 5 Worst Subnets")
        top_subnets = load_top_worst_subnets(start_dt, end_dt)
        st.dataframe(top_subnets, use_container_width=True, hide_index=True)

    if mode == "Evaluate":
        st.subheader("User Drillthrough")
        user_df = load_user_drillthrough(start_dt, end_dt, network_type, selected_subnets)
        st.dataframe(user_df, use_container_width=True, hide_index=True)
    else:
        st.subheader("Comparison Summary")
        compare_df = load_top_worst_subnets(start_dt, end_dt)
        st.dataframe(compare_df, use_container_width=True, hide_index=True)


def render_open_tickets():
    st.subheader("Open Tickets")
    tickets_df = load_open_tickets()
    if tickets_df.empty:
        st.info("No open tickets found.")
        return

    st.dataframe(
        tickets_df[
            [
                "ticket_id",
                "ticket_status",
                "subnet",
                "connection_type",
                "region",
                "country",
                "run_date",
                "monitoring_end_date",
                "repeat_count",
                "users_affected_7d",
                "hours_affected_7d",
                "max_severity_band",
            ]
        ],
        use_container_width=True,
        hide_index=True,
    )

    ticket_options = []
    for _, row in tickets_df.iterrows():
        label = f"{row.get('ticket_id') or row['alert_id']} | {row['subnet']} | {row['ticket_status']}"
        ticket_options.append((label, row["alert_id"]))

    selected_label = st.selectbox("Select Ticket", [x[0] for x in ticket_options], index=0)
    selected_alert_id = dict(ticket_options)[selected_label]
    ticket_row = tickets_df[tickets_df["alert_id"] == selected_alert_id].iloc[0]

    st.markdown("### Ticket Details")
    st.text_area("Ticket Body", value=str(ticket_row.get("ticket_body") or ""), height=260)

    st.markdown("### 30-Day Monitoring")
    monitor_df = load_ticket_monitoring(selected_alert_id)
    if monitor_df.empty:
        st.info("No monitoring rows found for this ticket yet.")
        return

    render_line_chart(monitor_df, "monitor_date", "users_affected_day", "Users Impacted by Monitoring Date", "Users Impacted")
    st.dataframe(monitor_df, use_container_width=True, hide_index=True)


def main():
    st.title(APP_TITLE)
    try:
        _ = get_access_token()
    except Exception as e:
        st.error(f"Authentication failed: {e}")
        st.stop()

    home_tab, tickets_tab = st.tabs(["Home", "Open Tickets"])
    with home_tab:
        render_home()
    with tickets_tab:
        render_open_tickets()


if __name__ == "__main__":
    main()
