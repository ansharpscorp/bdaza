import json
import os
import tempfile

import requests
from cryptography.hazmat.primitives.serialization import pkcs12


def load_pfx_cert_and_key(pfx_path, password: str = None):
    """Extract cert and private key from a .pfx file."""
    with open(pfx_path, "rb") as f:
        pfx_data = f.read()

    private_key, cert, _ = pkcs12.load_key_and_certificates(
        pfx_data,
        password.encode("utf‑8") if password else None,
    )

    return cert, private_key


def pfx_to_temp_pem(pfx_path, password: str = None):
    """Convert PFX to a temporary PEM file (cert + decrypted key) for requests."""
    cert, private_key = load_pfx_cert_and_key(pfx_path, password)

    # Create temp PEM file
    temp_pem = tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False)

    # private key
    temp_pem.write(
        private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ).decode("utf‑8")
    )

    # certificate
    temp_pem.write(
        cert.public_bytes(serialization.Encoding.PEM).decode("utf‑8")
    )

    temp_pem.close()
    return temp_pem.name


def main():
    # Load config
    with open("config.json", "r") as f:
        config = json.load(f)

    EVA_URL = config["eva_url"]
    LOGIN_URL = EVA_URL + config["login_path"]
    SECRET_PATH_TEMPLATE = config["secret_path_template"]
    SERVICE_PRINCIPAL = "my-service-principal"  # adjust
    SECRET_PATH = SECRET_PATH_TEMPLATE.format(service_principal=SERVICE_PRINCIPAL)

    PFX_PATH = config["pfx_path"]
    PFX_PASSWORD = config.get("pfx_password")
    LOGIN_NAME = config["login_name"]
    VERIFY_SSL = config["verify_ssl"]

    # Convert PFX → temp PEM
    temp_pem_path = pfx_to_temp_pem(PFX_PATH, PFX_PASSWORD)

    try:
        # === Login with client cert (now in PEM) ===
        resp_login = requests.post(
            LOGIN_URL,
            json={"name": LOGIN_NAME},  # or {"role": ...}
            cert=temp_pem_path,
            verify=VERIFY_SSL,
        )

        if resp_login.status_code != 200:
            print(f"Login failed: {resp_login.status_code}")
            print(resp_login.text)
            return

        login_data = resp_login.json()
        access_token = login_data.get("auth", {}).get("client_token")

        if not access_token:
            print("No token in login response; check EVA vault API shape.")
            return

        print("Logged in; token obtained.")

        # === Retrieve service‑principal secret ===
        secret_resp = requests.get(
            SECRET_PATH,
            headers={"X-Vault-Token": access_token},
            verify=VERIFY_SSL,
        )

        if secret_resp.status_code != 200:
            print(f"Secret fetch failed: {secret_resp.status_code}")
            print(secret_resp.text)
            return

        secret_data = secret_resp.json()
        print("Secret data:", json.dumps(secret_data, indent=2))

    finally:
        # Remove temp PEM
        try:
            os.unlink(temp_pem_path)
        except OSError:
            pass


if __name__ == "__main__":
    import serialization  # from cryptography.hazmat.primitives.serialization
    main()
