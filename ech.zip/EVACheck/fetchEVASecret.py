import json
import requests
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
from cryptography.x509 import load_pem_x509_certificate


# === Utility: load decrypted key from PEM (encrypted or not) ===
def load_cert_and_key(cert_path, key_path, password=None):
    # Read cert (must be PEM)
    with open(cert_path, "rb") as f:
        cert_data = f.read()
    cert = load_pem_x509_certificate(cert_data, default_backend())

    # If key is in same PEM, try to load from cert_path
    if key_path is None:
        with open(cert_path, "rb") as f:
            der_data = f.read()
    else:
        with open(key_path, "rb") as f:
            der_data = f.read()

    # Load private key; decrypt if encrypted
    private_key = serialization.load_pem_private_key(
        der_data,
        password=None if password is None else password.encode("utf‑8"),
        backend=default_backend(),
    )

    return cert, private_key


# === Main script ===
def main():
    # Load config
    with open("config.json", "r") as f:
        config = json.load(f)

    EVA_URL = config["eva_url"]
    LOGIN_URL = EVA_URL + config["login_path"]
    SECRET_PATH_TEMPLATE = config["secret_path_template"]
    SERVICE_PRINCIPAL = "my-service-principal"  # adjust as needed
    SECRET_PATH = SECRET_PATH_TEMPLATE.format(service_principal=SERVICE_PRINCIPAL)

    CERT_PATH = config["cert_path"]
    KEY_PATH = config.get("key_path")
    KEY_PASSWORD = config.get("key_password")
    LOGIN_NAME = config["login_name"]
    VERIFY_SSL = config["verify_ssl"]

    # Load cert + key (decrypted in memory)
    cert, private_key = load_cert_and_key(CERT_PATH, KEY_PATH, KEY_PASSWORD)

    # Export decrypted key PEM to bytes; requests still expects PEM-style files on disk
    # If you want to avoid writing to disk, use hvac over a custom adapter (not shown here).
    # For simplicity, we write to a temp decrypted key on disk (remove when done).
    # This step is workaround because requests cannot consume key bytes directly.

    # In practice, the cleanest option is to:
    # - decrypt the key once manually (e.g., `openssl rsa -in client.pem -out decrypted.key`),
    # - point KEY_PATH in config.json to that decrypted file,
    # - then just use:
    key_pass = None if KEY_PASSWORD is None else KEY_PASSWORD.encode("utf‑8")

    # If you’re okay with a temporary decrypted key file:
    import tempfile
    import os

    with tempfile.NamedTemporaryFile(mode="w", suffix=".key", delete=False) as f:
        decrypted_key_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        f.write(decrypted_key_pem.decode("utf‑8"))
        temp_key_path = f.name

    try:
        # === Login with client cert ===
        resp_login = requests.post(
            LOGIN_URL,
            json={"name": LOGIN_NAME},  # or {"role": ...}
            cert=(CERT_PATH, temp_key_path),
            verify=VERIFY_SSL,
        )

        if resp_login.status_code != 200:
            print(f"Login failed: {resp_login.status_code}")
            print(resp_login.text)
            return

        login_data = resp_login.json()
        access_token = login_data.get("auth", {}).get("client_token")

        if not access_token:
            print("No token in login response; check EVA vault API shape.")
            return

        print("Logged in; token obtained.")

        # === Retrieve service‑principal secret ===
        secret_resp = requests.get(
            SECRET_PATH,
            headers={"X-Vault-Token": access_token},
            verify=VERIFY_SSL,
        )

        if secret_resp.status_code != 200:
            print(f"Secret fetch failed: {secret_resp.status_code}")
            print(secret_resp.text)
            return

        secret_data = secret_resp.json()
        print("Secret data:", json.dumps(secret_data, indent=2))

    finally:
        # Remove temporary decrypted key
        try:
            os.unlink(temp_key_path)
        except OSError:
            pass


if __name__ == "__main__":
    main()
