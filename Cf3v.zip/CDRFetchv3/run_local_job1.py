import json
import sys
from src.job1_graph_to_json_stage_v3 import load_config, GraphToJsonStageJobV3


def main():
    config_path = sys.argv[1] if len(sys.argv) > 1 else "config.json"
    cfg = load_config(config_path)
    job = GraphToJsonStageJobV3(cfg)
    result = job.run()
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()