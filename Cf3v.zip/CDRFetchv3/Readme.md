cdr_pipeline_v3/
│
├── config.json
├── requirements.txt
├── run_local_job1.py
│
├── src/
│   ├── __init__.py
│   └── job1_graph_to_json_stage_v3.py
│
└── databricks/
    └── databricks_merge_stage_to_delta.py