import os
import json
import time
import uuid
import random
import asyncio
import threading
from datetime import datetime, timedelta, timezone
from typing import Dict, Any, List, Optional, Tuple

import aiohttp
import requests
from azure.identity import ClientSecretCredential
from azure.storage.filedatalake import DataLakeServiceClient
from azure.core.exceptions import ResourceNotFoundError
from databricks import sql


# ============================================================
# CONFIG
# ============================================================

def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    if config_path is None:
        config_path = os.getenv("JOB1_CONFIG_PATH", "config.json")
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


# ============================================================
# HELPERS
# ============================================================

def log_info(msg: str) -> None:
    print(msg, flush=True)

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

def floor_to_hour(dt: datetime) -> datetime:
    return dt.replace(minute=0, second=0, microsecond=0)

def to_utc_str(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def parse_date_utc(date_str: str, hour: int = 0) -> datetime:
    return datetime.strptime(f"{date_str} {hour:02d}:00:00", "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)

def date_parts_from_dt(dt: datetime) -> Tuple[str, str, str]:
    return dt.strftime("%Y"), dt.strftime("%m"), dt.strftime("%d")

async def async_sleep_with_jitter(seconds: float) -> None:
    await asyncio.sleep(seconds + random.uniform(0, 1.0))

def format_duration(seconds: float) -> str:
    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}"

def safe_iso_to_naive(dt_str: Optional[str]) -> Optional[str]:
    if not dt_str:
        return None
    return datetime.fromisoformat(dt_str.replace("Z", "+00:00")).replace(tzinfo=None).isoformat(sep=" ")

def dt_to_sql(dt: Optional[datetime]) -> Optional[str]:
    if dt is None:
        return None
    return dt.replace(tzinfo=None).isoformat(sep=" ")

def chunked(items: List[str], size: int) -> List[List[str]]:
    return [items[i:i + size] for i in range(0, len(items), size)]

def get_15_minute_intervals(hour_start: datetime) -> List[Tuple[datetime, datetime]]:
    return [
        (hour_start + timedelta(minutes=0),  hour_start + timedelta(minutes=15)),
        (hour_start + timedelta(minutes=15), hour_start + timedelta(minutes=30)),
        (hour_start + timedelta(minutes=30), hour_start + timedelta(minutes=45)),
        (hour_start + timedelta(minutes=45), hour_start + timedelta(minutes=60)),
    ]


# ============================================================
# ADLS
# ============================================================

class ADLSWriter:
    def __init__(
        self,
        tenant_id: str,
        client_id: str,
        client_secret: str,
        storage_account: str,
        container: str
    ):
        self.storage_account = storage_account
        self.container = container

        credential = ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )

        account_url = f"https://{storage_account}.dfs.core.windows.net"
        self.service = DataLakeServiceClient(account_url=account_url, credential=credential)
        self.file_system = self.service.get_file_system_client(container)

    def path_exists(self, path: str) -> bool:
        try:
            self.file_system.get_file_client(path).get_file_properties()
            return True
        except ResourceNotFoundError:
            return False

    def safe_rm(self, path: str) -> None:
        try:
            self.file_system.delete_file(path)
        except Exception:
            pass

    def write_text(self, path: str, content: str, overwrite: bool = True) -> None:
        file_client = self.file_system.get_file_client(path)
        file_client.upload_data(content.encode("utf-8"), overwrite=overwrite)

    def abfss_path(self, relative_path: str) -> str:
        return f"abfss://{self.container}@{self.storage_account}.dfs.core.windows.net/{relative_path}"


# ============================================================
# STAGE WRITER
# ============================================================

class StageWriter:
    def __init__(
        self,
        adls_writer: ADLSWriter,
        json_folder: str,
        manifest_stage_folder: str,
        checkpoint_stage_folder: str
    ):
        self.writer = adls_writer
        self.json_folder = json_folder.strip("/")
        self.manifest_stage_folder = manifest_stage_folder.strip("/")
        self.checkpoint_stage_folder = checkpoint_stage_folder.strip("/")

    def get_json_target_path(self, call_id: str, start_dt_str: str) -> str:
        start_dt = datetime.fromisoformat(start_dt_str.replace("Z", "+00:00"))
        yyyy, mm, dd = date_parts_from_dt(start_dt)
        return f"{self.json_folder}/{yyyy}/{mm}/{dd}/{call_id}.json"

    def _stage_file_name(self, prefix: str, interval_start: datetime, interval_end: datetime) -> str:
        run_id = uuid.uuid4().hex
        return (
            f"{prefix}_"
            f"{interval_start.strftime('%Y%m%d_%H%M%S')}_"
            f"{interval_end.strftime('%H%M%S')}_"
            f"{run_id}.json"
        )

    def write_manifest_batch(self, rows: List[Dict[str, Any]], interval_start: datetime, interval_end: datetime) -> Optional[str]:
        if not rows:
            return None
        path = f"{self.manifest_stage_folder}/{self._stage_file_name('manifest', interval_start, interval_end)}"
        self.writer.write_text(path, json.dumps(rows, ensure_ascii=False, indent=2), overwrite=True)
        return path

    def write_checkpoint_row(self, row: Dict[str, Any], interval_start: datetime, interval_end: datetime) -> str:
        path = f"{self.checkpoint_stage_folder}/{self._stage_file_name('checkpoint', interval_start, interval_end)}"
        self.writer.write_text(path, json.dumps([row], ensure_ascii=False, indent=2), overwrite=True)
        return path


# ============================================================
# DATABRICKS MANIFEST READER
# ============================================================

class DatabricksManifestReader:
    """
    v3:
    - native parameterized SQL
    - in-memory cache for repeated lookups
    """
    def __init__(self, host: str, http_path: str, token: str, manifest_table: str, lookup_batch_size: int = 200):
        self.host = host.replace("https://", "").replace("http://", "")
        self.http_path = http_path
        self.token = token
        self.manifest_table = manifest_table
        self.lookup_batch_size = lookup_batch_size
        self.lock = threading.Lock()
        self._success_cache: set[str] = set()

    def _connect(self):
        return sql.connect(
            server_hostname=self.host,
            http_path=self.http_path,
            access_token=self.token
        )

    def mark_successful(self, call_ids: List[str]) -> None:
        self._success_cache.update(call_ids)

    def get_already_successful_json_ids(self, call_ids: List[str]) -> set[str]:
        if not call_ids:
            return set()

        cached = {cid for cid in call_ids if cid in self._success_cache}
        missing = [cid for cid in call_ids if cid not in self._success_cache]

        found = set(cached)
        if not missing:
            return found

        with self.lock:
            with self._connect() as conn:
                with conn.cursor() as cur:
                    for group in chunked(missing, self.lookup_batch_size):
                        placeholders = ",".join(["?"] * len(group))
                        query = f"""
                        SELECT DISTINCT call_id
                        FROM {self.manifest_table}
                        WHERE json_status = ?
                          AND call_id IN ({placeholders})
                        """
                        params = ["SUCCESS", *group]
                        cur.execute(query, params)

                        batch_found = {row[0] for row in cur.fetchall()}
                        self._success_cache.update(batch_found)
                        found.update(batch_found)

        return found


# ============================================================
# GRAPH TOKEN MANAGER
# ============================================================

class GraphTokenManager:
    def __init__(self, tenant_id: str, client_id: str, client_secret: str):
        self.tenant_id = tenant_id
        self.client_id = client_id
        self.client_secret = client_secret
        self.access_token = None
        self.expiry_epoch = 0
        self.lock = threading.Lock()

    def get_token(self, force_refresh: bool = False) -> str:
        with self.lock:
            now_epoch = time.time()

            if (
                not force_refresh
                and self.access_token is not None
                and now_epoch < self.expiry_epoch - 300
            ):
                return self.access_token

            token_url = f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token"
            payload = {
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "scope": "https://graph.microsoft.com/.default",
                "grant_type": "client_credentials"
            }

            response = requests.post(token_url, data=payload, timeout=60)
            response.raise_for_status()
            token_json = response.json()

            self.access_token = token_json["access_token"]
            expires_in = int(token_json.get("expires_in", 3600))
            self.expiry_epoch = now_epoch + expires_in
            return self.access_token


# ============================================================
# ASYNC GRAPH CLIENT
# ============================================================

class AsyncGraphClient:
    def __init__(self, token_manager: GraphTokenManager, retry_limit: int, request_timeout: int, max_connections: int = 16):
        self.tm = token_manager
        self.retry_limit = retry_limit
        self.request_timeout = request_timeout
        self.max_connections = max_connections
        self._recent_429 = 0
        self._recent_429_lock = asyncio.Lock()

    async def _headers(self) -> Dict[str, str]:
        token = self.tm.get_token()
        return {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json"
        }

    async def _inc_429(self):
        async with self._recent_429_lock:
            self._recent_429 += 1

    async def reset_interval_throttle_counter(self):
        async with self._recent_429_lock:
            self._recent_429 = 0

    async def recent_429(self) -> int:
        async with self._recent_429_lock:
            return self._recent_429

    async def get_json(self, session: aiohttp.ClientSession, url: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        last_error = None

        for attempt in range(self.retry_limit + 1):
            try:
                headers = await self._headers()
                timeout = aiohttp.ClientTimeout(total=self.request_timeout)

                async with session.get(url, headers=headers, params=params, timeout=timeout) as resp:
                    if resp.status == 401:
                        self.tm.get_token(force_refresh=True)
                        if attempt < self.retry_limit:
                            continue

                    if resp.status == 429:
                        await self._inc_429()
                        retry_after = resp.headers.get("Retry-After")
                        wait_sec = int(retry_after) if retry_after and retry_after.isdigit() else min(60, 2 ** attempt)
                        await async_sleep_with_jitter(wait_sec)
                        if attempt < self.retry_limit:
                            continue

                    if resp.status in (500, 502, 503, 504):
                        retry_after = resp.headers.get("Retry-After")
                        wait_sec = int(retry_after) if retry_after and retry_after.isdigit() else min(60, 2 ** attempt)
                        await async_sleep_with_jitter(wait_sec)
                        if attempt < self.retry_limit:
                            continue

                    if resp.status >= 400:
                        text = await resp.text()
                        raise RuntimeError(f"HTTP {resp.status}: {text}")

                    return await resp.json()

            except Exception as e:
                last_error = e
                if attempt < self.retry_limit:
                    await async_sleep_with_jitter(min(60, 2 ** attempt))
                    continue

        raise last_error

    async def get_all_pages(self, session: aiohttp.ClientSession, url: str, params: Optional[Dict[str, Any]] = None) -> Tuple[List[Dict[str, Any]], Optional[str]]:
        all_items = []
        next_url = url
        next_params = params.copy() if params else None
        first_context = None

        while next_url:
            payload = await self.get_json(session, next_url, next_params)

            if first_context is None:
                first_context = payload.get("@odata.context")

            batch = payload.get("value", [])
            if batch:
                all_items.extend(batch)

            next_url = payload.get("@odata.nextLink")
            next_params = None

        return all_items, first_context


# ============================================================
# PIPELINE V3
# ============================================================

class GraphToJsonStageJobV3:
    def __init__(self, config: Dict[str, Any]):
        self.cfg = config

        self.GRAPH_BASE_URL = self.cfg.get("graph_base_url", "https://graph.microsoft.com/v1.0")
        self.REQUEST_TIMEOUT = int(self.cfg.get("request_timeout", 120))
        self.RETRY_LIMIT = int(self.cfg.get("retry_limit", 5))
        self.GRAPH_MAX_CONNECTIONS = int(self.cfg.get("graph_max_connections", 16))

        self.BASE_WORKERS = int(self.cfg.get("base_workers", 8))
        self.MIN_WORKERS = int(self.cfg.get("min_workers", 2))
        self.MAX_WORKERS = int(self.cfg.get("max_workers", 16))

        self.OVERWRITE_EXISTING = bool(self.cfg.get("overwrite_existing", False))
        self.PRINT_PER_CALL_SUCCESS = bool(self.cfg.get("print_per_call_success", False))
        self.PRINT_PER_CALL_FAILURE = bool(self.cfg.get("print_per_call_failure", False))

        self.fetchDate = self.cfg.get("fetchDate", "current")
        self.startDate = self.cfg.get("startDate")
        self.endDate = self.cfg.get("endDate")
        self.startHour = int(self.cfg.get("startHour", 0))
        self.endHour = int(self.cfg.get("endHour", 24))

        self.adls_writer = ADLSWriter(
            tenant_id=self.cfg["tenant_id"],
            client_id=self.cfg["client_id"],
            client_secret=self.cfg["client_secret"],
            storage_account=self.cfg["storage_account"],
            container=self.cfg["storage_container"],
        )

        self.stage_writer = StageWriter(
            adls_writer=self.adls_writer,
            json_folder=self.cfg["json_folder"],
            manifest_stage_folder=self.cfg["manifest_stage_folder"],
            checkpoint_stage_folder=self.cfg["checkpoint_stage_folder"],
        )

        self.manifest_reader = DatabricksManifestReader(
            host=self.cfg["databricks_host"],
            http_path=self.cfg["databricks_sql_http_path"],
            token=self.cfg["databricks_token"],
            manifest_table=self.cfg.get("manifest_table", "default.graph_callrecord_manifest"),
            lookup_batch_size=int(self.cfg.get("manifest_lookup_batch_size", 200))
        )

        self.token_manager = GraphTokenManager(
            tenant_id=self.cfg["tenant_id"],
            client_id=self.cfg["client_id"],
            client_secret=self.cfg["client_secret"]
        )

        self.graph_client = AsyncGraphClient(
            token_manager=self.token_manager,
            retry_limit=self.RETRY_LIMIT,
            request_timeout=self.REQUEST_TIMEOUT,
            max_connections=self.GRAPH_MAX_CONNECTIONS
        )

    def get_last_complete_hour_start_utc(self) -> datetime:
        return floor_to_hour(utc_now()) - timedelta(hours=1)

    def get_requested_window(self) -> Tuple[datetime, datetime]:
        if self.fetchDate.lower() == "current":
            now_utc = utc_now()
            day_start = now_utc.replace(hour=0, minute=0, second=0, microsecond=0)
            last_complete_hour_start = self.get_last_complete_hour_start_utc()
            exclusive_end = last_complete_hour_start + timedelta(hours=1)
            return day_start, exclusive_end

        raw_start = parse_date_utc(self.startDate, 0) + timedelta(hours=self.startHour)
        raw_end = parse_date_utc(self.endDate, 0) + timedelta(hours=self.endHour)
        return raw_start, raw_end

    def validate_inputs(self, window_start: datetime, window_end: datetime) -> None:
        if self.fetchDate.lower() not in ("current", "range"):
            raise ValueError("fetchDate must be either 'current' or 'range'")

        if self.fetchDate.lower() == "range":
            if self.startHour < 0 or self.startHour > 23:
                raise ValueError("startHour must be between 0 and 23")
            if self.endHour < 1 or self.endHour > 24:
                raise ValueError("endHour must be between 1 and 24")
            if window_end <= window_start:
                raise ValueError("endHour must be greater than startHour")

    def choose_concurrency(self, base_workers: int, recent_429: int) -> int:
        if recent_429 >= 20:
            return max(self.MIN_WORKERS, 2)
        elif recent_429 >= 10:
            return max(self.MIN_WORKERS, 4)
        elif recent_429 >= 5:
            return min(base_workers, 6)
        return min(base_workers, self.MAX_WORKERS)

    async def list_call_ids_for_interval(self, session: aiohttp.ClientSession, interval_start: datetime, interval_end: datetime) -> List[str]:
        url = f"{self.GRAPH_BASE_URL}/communications/callRecords"
        filter_expr = (
            f"startDateTime ge {to_utc_str(interval_start)} "
            f"and startDateTime lt {to_utc_str(interval_end)}"
        )
        params = {"$filter": filter_expr}
        items, _ = await self.graph_client.get_all_pages(session, url, params=params)
        return [item["id"] for item in items if item.get("id")]

    async def get_callrecord_base(self, session: aiohttp.ClientSession, call_id: str) -> Dict[str, Any]:
        return await self.graph_client.get_json(session, f"{self.GRAPH_BASE_URL}/communications/callRecords/{call_id}")

    async def get_participants_v2(self, session: aiohttp.ClientSession, call_id: str) -> Tuple[List[Dict[str, Any]], Optional[str]]:
        return await self.graph_client.get_all_pages(
            session,
            f"{self.GRAPH_BASE_URL}/communications/callRecords/{call_id}/participants_v2"
        )

    async def get_sessions_with_segments(self, session: aiohttp.ClientSession, call_id: str) -> Tuple[List[Dict[str, Any]], Optional[str]]:
        return await self.graph_client.get_all_pages(
            session,
            f"{self.GRAPH_BASE_URL}/communications/callRecords/{call_id}/sessions",
            params={"$expand": "segments"}
        )

    async def build_combined_json(self, session: aiohttp.ClientSession, call_id: str) -> Dict[str, Any]:
        base, participants_res, sessions_res = await asyncio.gather(
            self.get_callrecord_base(session, call_id),
            self.get_participants_v2(session, call_id),
            self.get_sessions_with_segments(session, call_id)
        )

        participants_v2, participants_v2_ctx = participants_res
        sessions, sessions_ctx = sessions_res

        return {
            "@odata.context": base.get("@odata.context"),
            "id": base.get("id"),
            "type": base.get("type"),
            "version": base.get("version"),
            "modalities": base.get("modalities"),
            "lastModifiedDateTime": base.get("lastModifiedDateTime"),
            "startDateTime": base.get("startDateTime"),
            "endDateTime": base.get("endDateTime"),
            "joinWebUrl": base.get("joinWebUrl"),
            "organizer": base.get("organizer"),
            "participants": base.get("participants"),
            "organizer_v2@odata.context": base.get("organizer_v2@odata.context"),
            "organizer_v2": base.get("organizer_v2"),
            "sessions@odata.context": sessions_ctx,
            "participants_v2": participants_v2,
            "sessions": sessions,
            "_metadata": {
                "downloadedAtUtc": to_utc_str(utc_now()),
                "sourceEndpoints": {
                    "callRecord": f"{self.GRAPH_BASE_URL}/communications/callRecords/{call_id}",
                    "participants_v2": f"{self.GRAPH_BASE_URL}/communications/callRecords/{call_id}/participants_v2",
                    "sessions": f"{self.GRAPH_BASE_URL}/communications/callRecords/{call_id}/sessions?$expand=segments"
                },
                "participants_v2@odata.context": participants_v2_ctx
            }
        }

    async def process_call_json(self, session: aiohttp.ClientSession, call_id: str, interval_start: datetime, interval_end: datetime) -> Dict[str, Any]:
        last_error = None

        for attempt in range(self.RETRY_LIMIT + 1):
            try:
                payload = await self.build_combined_json(session, call_id)

                record_start = payload.get("startDateTime")
                record_end = payload.get("endDateTime")

                if not record_start:
                    raise ValueError(f"Missing startDateTime for call_id={call_id}")

                json_relative_path = self.stage_writer.get_json_target_path(call_id, record_start)

                if self.OVERWRITE_EXISTING:
                    self.adls_writer.safe_rm(json_relative_path)
                elif self.adls_writer.path_exists(json_relative_path):
                    return {
                        "call_id": str(call_id),
                        "record_start_utc": safe_iso_to_naive(record_start),
                        "record_end_utc": safe_iso_to_naive(record_end),
                        "interval_start_utc": dt_to_sql(interval_start),
                        "interval_end_utc": dt_to_sql(interval_end),
                        "json_path": self.adls_writer.abfss_path(json_relative_path),
                        "parquet_path": None,
                        "json_status": "SUCCESS",
                        "parquet_status": "PENDING",
                        "json_retry_count": int(attempt),
                        "parquet_retry_count": 0,
                        "last_error": "SKIPPED_ALREADY_EXISTS",
                        "last_updated_utc": dt_to_sql(utc_now())
                    }

                self.adls_writer.write_text(
                    json_relative_path,
                    json.dumps(payload, ensure_ascii=False, indent=2),
                    overwrite=True
                )

                return {
                    "call_id": str(call_id),
                    "record_start_utc": safe_iso_to_naive(record_start),
                    "record_end_utc": safe_iso_to_naive(record_end),
                    "interval_start_utc": dt_to_sql(interval_start),
                    "interval_end_utc": dt_to_sql(interval_end),
                    "json_path": self.adls_writer.abfss_path(json_relative_path),
                    "parquet_path": None,
                    "json_status": "SUCCESS",
                    "parquet_status": "PENDING",
                    "json_retry_count": int(attempt),
                    "parquet_retry_count": 0,
                    "last_error": None,
                    "last_updated_utc": dt_to_sql(utc_now())
                }

            except Exception as e:
                last_error = f"{type(e).__name__}: {str(e)}"
                if attempt < self.RETRY_LIMIT:
                    await async_sleep_with_jitter(min(60, 2 ** attempt))

        return {
            "call_id": str(call_id),
            "record_start_utc": None,
            "record_end_utc": None,
            "interval_start_utc": dt_to_sql(interval_start),
            "interval_end_utc": dt_to_sql(interval_end),
            "json_path": None,
            "parquet_path": None,
            "json_status": "FAILED",
            "parquet_status": "PENDING",
            "json_retry_count": int(self.RETRY_LIMIT + 1),
            "parquet_retry_count": 0,
            "last_error": last_error,
            "last_updated_utc": dt_to_sql(utc_now())
        }

    async def run_interval_async(self, session: aiohttp.ClientSession, interval_start: datetime, interval_end: datetime) -> None:
        interval_begin_ts = time.time()
        await self.graph_client.reset_interval_throttle_counter()

        all_call_ids = sorted(set(await self.list_call_ids_for_interval(session, interval_start, interval_end)))
        found_count = len(all_call_ids)

        already_done = set()
        if not self.OVERWRITE_EXISTING and all_call_ids:
            already_done = self.manifest_reader.get_already_successful_json_ids(all_call_ids)

        pending_call_ids = [cid for cid in all_call_ids if cid not in already_done]

        skipped_count = len(already_done)
        pending_count = len(pending_call_ids)

        recent_429 = await self.graph_client.recent_429()
        concurrency = self.choose_concurrency(self.BASE_WORKERS, recent_429)
        semaphore = asyncio.Semaphore(concurrency)

        async def bounded(call_id: str):
            async with semaphore:
                return await self.process_call_json(session, call_id, interval_start, interval_end)

        tasks = [bounded(cid) for cid in pending_call_ids]
        batch_results = await asyncio.gather(*tasks) if tasks else []

        success_count = sum(1 for r in batch_results if r["json_status"] == "SUCCESS")
        fail_count = sum(1 for r in batch_results if r["json_status"] != "SUCCESS")

        successful_ids = [r["call_id"] for r in batch_results if r["json_status"] == "SUCCESS"]
        self.manifest_reader.mark_successful(successful_ids)

        checkpoint_row = {
            "interval_start_utc": dt_to_sql(interval_start),
            "interval_end_utc": dt_to_sql(interval_end),
            "listed_count": int(found_count),
            "json_success_count": int(success_count),
            "json_failed_count": int(fail_count),
            "status": "PARTIAL_SUCCESS" if fail_count > 0 else "SUCCESS",
            "last_updated_utc": dt_to_sql(utc_now()),
            "last_error": None
        }

        manifest_stage_path = self.stage_writer.write_manifest_batch(batch_results, interval_start, interval_end)
        checkpoint_stage_path = self.stage_writer.write_checkpoint_row(checkpoint_row, interval_start, interval_end)

        elapsed = time.time() - interval_begin_ts

        log_info(
            f"Interval: {to_utc_str(interval_start)} -> {to_utc_str(interval_end)} | "
            f"Found: {found_count} | Pending: {pending_count} | Skipped: {skipped_count}"
        )
        log_info(
            f"Json: Success: {success_count} | Failed: {fail_count} | TimeTaken: {format_duration(elapsed)}"
        )
        log_info(
            f"Stage: Manifest: {manifest_stage_path if manifest_stage_path else 'None'} | "
            f"Checkpoint: {checkpoint_stage_path}"
        )
        log_info("=" * 100)

    async def run_async(self) -> Dict[str, Any]:
        window_start, window_end = self.get_requested_window()
        self.validate_inputs(window_start, window_end)

        log_info(f"fetchDate         = {self.fetchDate}")
        log_info(f"Window start      = {to_utc_str(window_start)}")
        log_info(f"Window end(excl.) = {to_utc_str(window_end)}")

        connector = aiohttp.TCPConnector(limit=self.GRAPH_MAX_CONNECTIONS)
        async with aiohttp.ClientSession(connector=connector) as session:
            cursor = floor_to_hour(window_start)

            while cursor < window_end:
                hour_start = cursor

                for interval_start, interval_end in get_15_minute_intervals(hour_start):
                    if interval_start >= window_end:
                        break
                    if interval_end <= window_start:
                        continue

                    actual_start = max(interval_start, window_start)
                    actual_end = min(interval_end, window_end)

                    if actual_start < actual_end:
                        await self.run_interval_async(session, actual_start, actual_end)

                cursor = cursor + timedelta(hours=1)

        return {"status": "completed"}

    def run(self) -> Dict[str, Any]:
        return asyncio.run(self.run_async())