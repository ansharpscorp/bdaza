from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.window import Window

MANIFEST_TABLE = "default.graph_callrecord_manifest"
CHECKPOINT_TABLE = "default.graph_callrecord_interval_checkpoint"

MANIFEST_STAGE_PATH = "abfss://raw@mystorageacct.dfs.core.windows.net/teams/staging/manifest/"
CHECKPOINT_STAGE_PATH = "abfss://raw@mystorageacct.dfs.core.windows.net/teams/staging/checkpoint/"

MANIFEST_ARCHIVE_PATH = "abfss://raw@mystorageacct.dfs.core.windows.net/teams/staging_archive/manifest/"
CHECKPOINT_ARCHIVE_PATH = "abfss://raw@mystorageacct.dfs.core.windows.net/teams/staging_archive/checkpoint/"

MANIFEST_SCHEMA = T.StructType([
    T.StructField("call_id", T.StringType(), True),
    T.StructField("record_start_utc", T.TimestampType(), True),
    T.StructField("record_end_utc", T.TimestampType(), True),
    T.StructField("interval_start_utc", T.TimestampType(), True),
    T.StructField("interval_end_utc", T.TimestampType(), True),
    T.StructField("json_path", T.StringType(), True),
    T.StructField("parquet_path", T.StringType(), True),
    T.StructField("json_status", T.StringType(), True),
    T.StructField("parquet_status", T.StringType(), True),
    T.StructField("json_retry_count", T.IntegerType(), True),
    T.StructField("parquet_retry_count", T.IntegerType(), True),
    T.StructField("last_error", T.StringType(), True),
    T.StructField("last_updated_utc", T.TimestampType(), True),
])

CHECKPOINT_SCHEMA = T.StructType([
    T.StructField("interval_start_utc", T.TimestampType(), True),
    T.StructField("interval_end_utc", T.TimestampType(), True),
    T.StructField("listed_count", T.LongType(), True),
    T.StructField("json_success_count", T.LongType(), True),
    T.StructField("json_failed_count", T.LongType(), True),
    T.StructField("status", T.StringType(), True),
    T.StructField("last_updated_utc", T.TimestampType(), True),
    T.StructField("last_error", T.StringType(), True),
])

def path_has_files(path: str) -> bool:
    try:
        return len(dbutils.fs.ls(path)) > 0
    except Exception:
        return False

def archive_stage_files(src_path: str, archive_path: str) -> None:
    try:
        dbutils.fs.mkdirs(archive_path)
    except Exception:
        pass
    for item in dbutils.fs.ls(src_path):
        dbutils.fs.mv(item.path, archive_path.rstrip("/") + "/" + item.name.rstrip("/"), True)

manifest_has_files = path_has_files(MANIFEST_STAGE_PATH)
checkpoint_has_files = path_has_files(CHECKPOINT_STAGE_PATH)

if manifest_has_files:
    manifest_stage_df = (
        spark.read.schema(MANIFEST_SCHEMA).json(MANIFEST_STAGE_PATH)
        .filter(F.col("call_id").isNotNull())
        .withColumn("rn", F.row_number().over(Window.partitionBy("call_id").orderBy(F.col("last_updated_utc").desc_nulls_last())))
        .filter(F.col("rn") == 1)
        .drop("rn")
    )
    manifest_stage_df.createOrReplaceTempView("manifest_stage_vw")

    spark.sql(f"""
    MERGE INTO {MANIFEST_TABLE} tgt
    USING manifest_stage_vw src
      ON tgt.call_id = src.call_id
    WHEN MATCHED THEN UPDATE SET
      tgt.record_start_utc = src.record_start_utc,
      tgt.record_end_utc = src.record_end_utc,
      tgt.interval_start_utc = src.interval_start_utc,
      tgt.interval_end_utc = src.interval_end_utc,
      tgt.json_path = src.json_path,
      tgt.parquet_path = src.parquet_path,
      tgt.json_status = src.json_status,
      tgt.parquet_status = src.parquet_status,
      tgt.json_retry_count = src.json_retry_count,
      tgt.parquet_retry_count = src.parquet_retry_count,
      tgt.last_error = src.last_error,
      tgt.last_updated_utc = src.last_updated_utc
    WHEN NOT MATCHED THEN INSERT (
      call_id, record_start_utc, record_end_utc, interval_start_utc, interval_end_utc,
      json_path, parquet_path, json_status, parquet_status, json_retry_count,
      parquet_retry_count, last_error, last_updated_utc
    ) VALUES (
      src.call_id, src.record_start_utc, src.record_end_utc, src.interval_start_utc, src.interval_end_utc,
      src.json_path, src.parquet_path, src.json_status, src.parquet_status, src.json_retry_count,
      src.parquet_retry_count, src.last_error, src.last_updated_utc
    )
    """)
    archive_stage_files(MANIFEST_STAGE_PATH, MANIFEST_ARCHIVE_PATH)

if checkpoint_has_files:
    checkpoint_stage_df = (
        spark.read.schema(CHECKPOINT_SCHEMA).json(CHECKPOINT_STAGE_PATH)
        .filter(F.col("interval_start_utc").isNotNull())
    )
    checkpoint_stage_df.write.format("delta").mode("append").saveAsTable(CHECKPOINT_TABLE)
    archive_stage_files(CHECKPOINT_STAGE_PATH, CHECKPOINT_ARCHIVE_PATH)