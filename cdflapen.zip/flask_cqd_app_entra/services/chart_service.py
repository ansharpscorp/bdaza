import plotly.express as px
import plotly.graph_objects as go
from plotly.offline import plot


def fig_to_div(fig):
    fig.update_layout(
        template="plotly_white",
        margin=dict(l=20, r=20, t=40, b=20),
        hovermode="x unified"
    )
    return plot(fig, output_type="div", include_plotlyjs=False)


def multi_line_chart(df, x, y_cols, title):
    fig = go.Figure()
    for col in y_cols:
        if col in df.columns:
            fig.add_trace(go.Scatter(x=df[x], y=df[col], mode="lines+markers", name=col))
    fig.update_layout(title=title, template="plotly_white")
    return fig_to_div(fig)


def bar_chart(df, x, y, title, orientation="v", color=None):
    if df.empty:
        fig = go.Figure()
        fig.update_layout(title=title)
        return fig_to_div(fig)
    fig = px.bar(df, x=x, y=y, color=color, title=title, orientation=orientation)
    return fig_to_div(fig)
