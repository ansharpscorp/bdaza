import pandas as pd
from config import Config
from db import run_query, sql_quote

VALID_MODE = {"evaluate", "compare"}
VALID_NETWORK_TYPES = {"wired", "wifi", "mobilebb", "all"}
VALID_WINDOWS = {"7", "30", "custom"}


def normalize_insight_inputs(args):
    mode = (args.get("mode", "evaluate") or "evaluate").lower()
    network_type = (args.get("network_type", "all") or "all").lower()
    subnet = args.get("subnet", "").strip()
    window = (args.get("window", "7") or "7").lower()
    start_date = args.get("start_date", "").strip()
    end_date = args.get("end_date", "").strip()
    compare_scope = (args.get("compare_scope", "building") or "building").lower()

    if mode not in VALID_MODE:
        mode = "evaluate"
    if network_type not in VALID_NETWORK_TYPES:
        network_type = "all"
    if window not in VALID_WINDOWS:
        window = "7"
    if compare_scope not in {"building", "site", "network_type"}:
        compare_scope = "building"

    return {
        "mode": mode,
        "network_type": network_type,
        "subnet": subnet,
        "window": window,
        "start_date": start_date,
        "end_date": end_date,
        "compare_scope": compare_scope,
    }


def get_subnet_list(network_type="all"):
    where = []
    if network_type != "all":
        where.append(f"lower(ConnectionType) = {sql_quote(network_type)}")
    where_sql = f"WHERE {' AND '.join(where)}" if where else ""
    q = f"""
    SELECT DISTINCT Subnet
    FROM {Config.TBL_HOURLY}
    {where_sql}
    ORDER BY Subnet
    """
    df = run_query(q)
    return df["Subnet"].dropna().tolist() if not df.empty else []


def build_date_where(inp):
    if inp["window"] == "custom" and inp["start_date"] and inp["end_date"]:
        return f"Date BETWEEN {sql_quote(inp['start_date'])} AND {sql_quote(inp['end_date'])}"
    days = 7 if inp["window"] == "7" else 30
    return f"Date >= date_sub(current_date(), {days})"


def build_network_where(inp):
    if inp["network_type"] == "all":
        return ""
    return f" AND lower(ConnectionType) = {sql_quote(inp['network_type'])}"


def build_plain_english_query(inp):
    time_desc = {
        "7": "the last 7 days",
        "30": "the last 30 days",
        "custom": f"the date range from {inp['start_date']} to {inp['end_date']}",
    }[inp["window"]]

    subnet_desc = inp["subnet"] if inp["subnet"] else "[no subnet selected]"
    nt_desc = inp["network_type"].capitalize() if inp["network_type"] != "all" else "all network types"

    if inp["mode"] == "evaluate":
        return f"Evaluate subnet {subnet_desc} for {nt_desc} over {time_desc}."
    return f"Compare subnet {subnet_desc} against peer subnets in the same {inp['compare_scope']} for {nt_desc} over {time_desc}."


def get_subnet_context(subnet):
    q = f"""
    SELECT
      Subnet,
      COALESCE(Subnet_Building, 'Unknown') AS Subnet_Building,
      COALESCE(Subnet_Site, 'Unknown') AS Subnet_Site,
      COALESCE(ReflexiveIP_Region, 'Unknown') AS ReflexiveIP_Region
    FROM {Config.TBL_INCIDENT}
    WHERE Subnet = {sql_quote(subnet)}
    LIMIT 1
    """
    df = run_query(q)
    return df.iloc[0].to_dict() if not df.empty else {}


def get_evidence_table(inp):
    if not inp["subnet"]:
        return pd.DataFrame()
    where_sql = build_date_where(inp)
    network_sql = build_network_where(inp)
    q = f"""
    SELECT Date, Subnet, IncidentHours, MaxSeverity, PeakAffectedUsers,
           DistinctCallCount, DistinctSessionCount, Likely_Cause
    FROM {Config.TBL_INCIDENT}
    WHERE Subnet = {sql_quote(inp['subnet'])}
      AND {where_sql}
      {network_sql}
    ORDER BY Date DESC, MaxSeverity DESC
    LIMIT {Config.MAX_TABLE_ROWS}
    """
    return run_query(q)


def get_selected_subnet_daily(inp):
    if not inp["subnet"]:
        return pd.DataFrame()
    where_sql = build_date_where(inp)
    network_sql = build_network_where(inp)
    q = f"""
    SELECT Date,
      AVG(SeverityScore) AS AvgSeverityScore,
      MAX(AffectedUsers) AS PeakAffectedUsers,
      AVG(Jitter_Avg) AS AvgJitter,
      AVG(RTT_Avg) AS AvgRTT,
      AVG(PLR_Avg) AS AvgPLR
    FROM {Config.TBL_HOURLY}
    WHERE Subnet = {sql_quote(inp['subnet'])}
      AND {where_sql}
      {network_sql}
    GROUP BY Date
    ORDER BY Date
    """
    return run_query(q)


def get_peer_daily(inp):
    if not inp["subnet"]:
        return pd.DataFrame()
    context = get_subnet_context(inp["subnet"])
    if not context:
        return pd.DataFrame()
    where_sql = build_date_where(inp)
    network_sql = build_network_where(inp)
    peer_clauses = [f"Subnet <> {sql_quote(inp['subnet'])}"]
    if inp["compare_scope"] == "building":
        peer_clauses.append(f"COALESCE(Subnet_Building, 'Unknown') = {sql_quote(context.get('Subnet_Building', 'Unknown'))}")
    elif inp["compare_scope"] == "site":
        peer_clauses.append(f"COALESCE(Subnet_Site, 'Unknown') = {sql_quote(context.get('Subnet_Site', 'Unknown'))}")
    q = f"""
    SELECT Date,
      AVG(SeverityScore) AS PeerAvgSeverityScore,
      AVG(AffectedUsers) AS PeerAvgAffectedUsers,
      AVG(Jitter_Avg) AS PeerAvgJitter,
      AVG(RTT_Avg) AS PeerAvgRTT,
      AVG(PLR_Avg) AS PeerAvgPLR
    FROM {Config.TBL_HOURLY}
    WHERE {' AND '.join(peer_clauses)}
      AND {where_sql}
      {network_sql}
    GROUP BY Date
    ORDER BY Date
    """
    return run_query(q)


def get_peer_ranking(inp):
    if not inp["subnet"]:
        return pd.DataFrame()
    context = get_subnet_context(inp["subnet"])
    if not context:
        return pd.DataFrame()
    where_sql = build_date_where(inp)
    network_sql = build_network_where(inp)
    peer_clauses = []
    if inp["compare_scope"] == "building":
        peer_clauses.append(f"COALESCE(Subnet_Building, 'Unknown') = {sql_quote(context.get('Subnet_Building', 'Unknown'))}")
    elif inp["compare_scope"] == "site":
        peer_clauses.append(f"COALESCE(Subnet_Site, 'Unknown') = {sql_quote(context.get('Subnet_Site', 'Unknown'))}")
    q = f"""
    SELECT Subnet,
      SUM(IncidentHours) AS IncidentHours,
      MAX(MaxSeverity) AS MaxSeverity,
      MAX(PeakAffectedUsers) AS PeakAffectedUsers
    FROM {Config.TBL_INCIDENT}
    WHERE {where_sql}
      {network_sql}
      {"AND " + " AND ".join(peer_clauses) if peer_clauses else ""}
    GROUP BY Subnet
    ORDER BY MaxSeverity DESC, IncidentHours DESC
    LIMIT 20
    """
    return run_query(q)


def generate_grounded_summary(inp, selected_df, peer_df, evidence_df):
    if selected_df is None or selected_df.empty:
        return {
            "executive_summary": "No subnet is selected or no data is available for the selected window.",
            "technical_summary": "",
            "recommended_action": "",
        }

    avg_severity = selected_df["AvgSeverityScore"].mean()
    avg_users = selected_df["PeakAffectedUsers"].mean()
    peer_summary = ""
    if peer_df is not None and not peer_df.empty:
        peer_avg_severity = peer_df["PeerAvgSeverityScore"].mean()
        diff = avg_severity - peer_avg_severity
        if diff > 10:
            peer_summary = f"The selected subnet is materially worse than peer subnets, with average severity higher by {diff:.1f} points."
        elif diff > 3:
            peer_summary = f"The selected subnet is somewhat worse than its peer group, with average severity higher by {diff:.1f} points."
        elif diff < -3:
            peer_summary = f"The selected subnet is performing better than its peer group by about {abs(diff):.1f} severity points."
        else:
            peer_summary = "The selected subnet is broadly in line with its peer group."

    likely_cause = ""
    if evidence_df is not None and not evidence_df.empty and "Likely_Cause" in evidence_df.columns:
        cause_counts = evidence_df["Likely_Cause"].fillna("Unknown").value_counts()
        likely_cause = cause_counts.index[0] if len(cause_counts) else "Unknown"

    recommended_action = "Review subnet-local conditions first."
    if "wifi" in inp["network_type"]:
        recommended_action = "Prioritize WiFi capacity, coverage, roaming, and interference checks."
    elif "wired" in inp["network_type"]:
        recommended_action = "Prioritize LAN/WAN path review, uplink health, and routing or QoS checks."

    return {
        "executive_summary": (
            f"Subnet {inp['subnet']} shows average severity of {avg_severity:.1f} over the selected period, "
            f"with average peak affected users of {avg_users:.1f}. {peer_summary}"
        ),
        "technical_summary": (
            f"The pattern suggests repeated service degradation on the selected subnet. "
            f"Most likely cause from the evidence table: {likely_cause or 'Not enough data'}."
        ),
        "recommended_action": recommended_action,
    }
