import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key")

    DATABRICKS_HOST = os.getenv("DATABRICKS_HOST", "").strip()
    DATABRICKS_HTTP_PATH = os.getenv("DATABRICKS_HTTP_PATH", "").strip()

    AZURE_TENANT_ID = os.getenv("AZURE_TENANT_ID", "").strip()
    AZURE_CLIENT_ID = os.getenv("AZURE_CLIENT_ID", "").strip()
    AZURE_CLIENT_SECRET = os.getenv("AZURE_CLIENT_SECRET", "").strip()
    AZURE_SCOPE_GUID = os.getenv("AZURE_SCOPE_GUID", "").strip()

    DB_SCHEMA = os.getenv("DB_SCHEMA", "cqd_ml")

    TBL_INCIDENT = os.getenv("TBL_INCIDENT", f"{DB_SCHEMA}.cqd_incident_summaries")
    TBL_HOURLY = os.getenv("TBL_HOURLY", f"{DB_SCHEMA}.cqd_insights_hourly")
    TBL_CALL_DETAIL = os.getenv("TBL_CALL_DETAIL", f"{DB_SCHEMA}.cqd_call_details")
    TBL_CALL_SUMMARY = os.getenv("TBL_CALL_SUMMARY", f"{DB_SCHEMA}.cqd_call_summary")
    TBL_ROLLUP_SUBNET_DAY = os.getenv("TBL_ROLLUP_SUBNET_DAY", f"{DB_SCHEMA}.cqd_rollup_subnet_day")
    TBL_ROLLUP_REFIP_DAY = os.getenv("TBL_ROLLUP_REFIP_DAY", f"{DB_SCHEMA}.cqd_rollup_refip_day")

    DEFAULT_LOOKBACK_DAYS = int(os.getenv("DEFAULT_LOOKBACK_DAYS", "7"))
    MAX_TABLE_ROWS = int(os.getenv("MAX_TABLE_ROWS", "200"))

    @classmethod
    def validate(cls) -> None:
        required = {
            "DATABRICKS_HOST": cls.DATABRICKS_HOST,
            "DATABRICKS_HTTP_PATH": cls.DATABRICKS_HTTP_PATH,
            "AZURE_TENANT_ID": cls.AZURE_TENANT_ID,
            "AZURE_CLIENT_ID": cls.AZURE_CLIENT_ID,
            "AZURE_CLIENT_SECRET": cls.AZURE_CLIENT_SECRET,
            "AZURE_SCOPE_GUID": cls.AZURE_SCOPE_GUID,
        }
        missing = [k for k, v in required.items() if not v]
        if missing:
            raise ValueError(f"Missing required environment variables: {', '.join(missing)}")

    @classmethod
    def azure_scope(cls) -> str:
        return f"{cls.AZURE_SCOPE_GUID}/.default"
