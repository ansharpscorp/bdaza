# CQD Flask App (Microsoft Entra token flow)

## What this app includes
- Dashboard page with filters, KPI cards, region charts, trends, worst subnets, and alert table
- Subnet drillthrough page
- AI / insights page with evaluate and compare modes
- Microsoft Entra client credentials token flow using `<scope-guid>/.default`
- Standalone connectivity test file

## Project structure

```text
flask_cqd_app_entra/
├── app.py
├── config.py
├── db.py
├── standalone_test.py
├── requirements.txt
├── .env.example
├── README.md
├── services/
├── templates/
└── static/
```

## Setup
1. Copy `.env.example` to `.env`
2. Fill in your workspace, tenant, client ID, client secret, and scope GUID
3. Install packages:
   `pip install -r requirements.txt`
4. Run standalone test first:
   `python standalone_test.py`
5. Run the app:
   `python app.py`

## Important environment values
- `DATABRICKS_HOST` example: `https://adb-xxxxxxxxxxxxxxxx.x.azuredatabricks.net`
- `DATABRICKS_HTTP_PATH` example: `/sql/1.0/warehouses/xxxxxxxxxxxxxxxx`
- `AZURE_SCOPE_GUID` should be the GUID part used as `<guid>/.default`

## Troubleshooting
- If token fetch fails, verify tenant ID, client ID, client secret, and scope GUID
- If SQL connection fails after token fetch works, verify Databricks workspace access, warehouse permissions, and table permissions
