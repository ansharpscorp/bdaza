from flask import Flask, render_template, request, jsonify
from config import Config
from services.dashboard_service import (
    normalize_filters,
    get_filter_options,
    get_kpis,
    get_worst_subnets,
    get_alert_table,
    get_region_impact,
    get_trend,
    get_subnet_detail,
)
from services.insights_service import (
    normalize_insight_inputs,
    get_subnet_list,
    build_plain_english_query,
    get_selected_subnet_daily,
    get_peer_daily,
    get_peer_ranking,
    get_evidence_table,
    generate_grounded_summary,
)
from services.chart_service import bar_chart, multi_line_chart

app = Flask(__name__)
app.config.from_object(Config)


@app.route("/")
def home():
    return dashboard()


@app.route("/dashboard")
def dashboard():
    filters = normalize_filters(request.args)
    filter_options = get_filter_options()

    kpis = get_kpis(filters)
    worst_subnets = get_worst_subnets(filters)
    alert_table = get_alert_table(filters)
    region_impact = get_region_impact(filters)
    trend_7 = get_trend(7, filters["network_type"])
    trend_30 = get_trend(30, filters["network_type"])

    region_chart_div = bar_chart(region_impact, x="Region", y="IncidentHours", title="Region impact by incident hours")
    trend_7_div = multi_line_chart(trend_7, x="Date", y_cols=["IncidentCount", "IncidentHours", "PeakAffectedUsers", "AvgMaxSeverity"], title="Last 7 days trend")
    trend_30_div = multi_line_chart(trend_30, x="Date", y_cols=["IncidentCount", "IncidentHours", "PeakAffectedUsers", "AvgMaxSeverity"], title="Last 30 days trend")
    top_subnet_chart_div = bar_chart(worst_subnets.head(10), x="Subnet", y="ActionPriorityScore", title="Top actionable poor-performing subnets")

    return render_template(
        "dashboard.html",
        filters=filters,
        filter_options=filter_options,
        kpis=kpis,
        worst_subnets=worst_subnets.to_dict(orient="records"),
        alert_table=alert_table.to_dict(orient="records"),
        region_chart_div=region_chart_div,
        trend_7_div=trend_7_div,
        trend_30_div=trend_30_div,
        top_subnet_chart_div=top_subnet_chart_div,
    )


@app.route("/subnet/<path:subnet>")
def subnet_detail(subnet):
    lookback = request.args.get("lookback", "7")
    if lookback not in {"7", "30"}:
        lookback = "7"
    detail = get_subnet_detail(subnet=subnet, lookback=int(lookback))
    trend_div = multi_line_chart(detail["trend"], x="Date", y_cols=["IncidentHours", "MaxSeverity", "PeakAffectedUsers"], title=f"Subnet trend: {subnet}")
    return render_template(
        "subnet_detail.html",
        subnet=subnet,
        lookback=lookback,
        kpis=detail["kpis"],
        trend_div=trend_div,
        calls=detail["calls"].to_dict(orient="records"),
        users=detail["users"].to_dict(orient="records"),
    )


@app.route("/insights")
def insights():
    inp = normalize_insight_inputs(request.args)
    subnet_options = get_subnet_list(inp["network_type"])
    english_query = build_plain_english_query(inp)

    selected_df = get_selected_subnet_daily(inp) if inp["subnet"] else None
    peer_df = get_peer_daily(inp) if inp["subnet"] else None
    ranking_df = get_peer_ranking(inp) if inp["subnet"] else None
    evidence_df = get_evidence_table(inp) if inp["subnet"] else None

    selected_div = ""
    compare_div = ""
    peer_rank_div = ""
    ai_summary = {"executive_summary": "", "technical_summary": "", "recommended_action": ""}

    if inp["subnet"] and selected_df is not None and not selected_df.empty:
        if peer_df is not None and not peer_df.empty:
            merged = selected_df.merge(peer_df, on="Date", how="left")
            selected_div = multi_line_chart(merged, x="Date", y_cols=["AvgSeverityScore", "PeerAvgSeverityScore"], title="Selected subnet vs peer severity")
            compare_div = multi_line_chart(merged, x="Date", y_cols=["PeakAffectedUsers", "PeerAvgAffectedUsers"], title="Selected subnet vs peer affected users")
        else:
            selected_div = multi_line_chart(selected_df, x="Date", y_cols=["AvgSeverityScore", "PeakAffectedUsers", "AvgJitter", "AvgRTT"], title="Selected subnet trend")

        if ranking_df is not None and not ranking_df.empty:
            peer_rank_div = bar_chart(ranking_df.head(15), x="Subnet", y="IncidentHours", title="Peer subnet ranking by incident hours")

        ai_summary = generate_grounded_summary(inp, selected_df, peer_df, evidence_df)

    return render_template(
        "insights.html",
        inp=inp,
        subnet_options=subnet_options,
        english_query=english_query,
        selected_div=selected_div,
        compare_div=compare_div,
        peer_rank_div=peer_rank_div,
        evidence_rows=(evidence_df.to_dict(orient="records") if evidence_df is not None and not evidence_df.empty else []),
        ai_summary=ai_summary,
    )


@app.route("/api/subnets")
def api_subnets():
    network_type = request.args.get("network_type", "all").lower()
    return jsonify({"subnets": get_subnet_list(network_type)})


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
