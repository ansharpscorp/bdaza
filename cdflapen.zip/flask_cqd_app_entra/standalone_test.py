import json
import sys

import requests
from databricks import sql

from config import Config


def get_entra_token() -> str:
    Config.validate()
    url = f"https://login.microsoftonline.com/{Config.AZURE_TENANT_ID}/oauth2/v2.0/token"
    resp = requests.post(
        url,
        data={
            "grant_type": "client_credentials",
            "client_id": Config.AZURE_CLIENT_ID,
            "client_secret": Config.AZURE_CLIENT_SECRET,
            "scope": Config.azure_scope(),
        },
        timeout=30,
    )
    print(f"Token endpoint status: {resp.status_code}")
    if not resp.ok:
        print(resp.text)
        resp.raise_for_status()

    payload = resp.json()
    token = payload.get("access_token")
    if not token:
        raise RuntimeError("No access_token returned by Microsoft Entra token endpoint.")
    print("Token acquired successfully.")
    return token


def test_databricks_sql(token: str) -> None:
    server_hostname = (
        Config.DATABRICKS_HOST
        .replace("https://", "")
        .replace("http://", "")
        .strip()
        .rstrip("/")
    )

    with sql.connect(
        server_hostname=server_hostname,
        http_path=Config.DATABRICKS_HTTP_PATH,
        access_token=token,
    ) as conn:
        with conn.cursor() as cursor:
            cursor.execute("SELECT current_date() AS today, current_timestamp() AS now_ts")
            rows = cursor.fetchall()
            print("Databricks SQL connection successful.")
            print(rows)


def main() -> int:
    try:
        token = get_entra_token()
        print(f"Token preview: {token[:40]}...")
        test_databricks_sql(token)
        return 0
    except Exception as exc:
        print("Test failed:")
        print(str(exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
