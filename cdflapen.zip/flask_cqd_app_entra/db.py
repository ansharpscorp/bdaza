import time
from typing import Optional

import pandas as pd
import requests
from databricks import sql

from config import Config


class EntraTokenManager:
    def __init__(self) -> None:
        self._access_token: Optional[str] = None
        self._expires_at_epoch: float = 0.0

    def _token_url(self) -> str:
        return f"https://login.microsoftonline.com/{Config.AZURE_TENANT_ID}/oauth2/v2.0/token"

    def _needs_refresh(self) -> bool:
        return not self._access_token or time.time() >= max(0.0, self._expires_at_epoch - 60)

    def _fetch_token(self) -> None:
        Config.validate()

        response = requests.post(
            self._token_url(),
            data={
                "grant_type": "client_credentials",
                "client_id": Config.AZURE_CLIENT_ID,
                "client_secret": Config.AZURE_CLIENT_SECRET,
                "scope": Config.azure_scope(),
            },
            timeout=30,
        )
        response.raise_for_status()

        payload = response.json()
        token = payload.get("access_token")
        expires_in = int(payload.get("expires_in", 3600))

        if not token:
            raise RuntimeError("Microsoft Entra token response did not include access_token.")

        self._access_token = token
        self._expires_at_epoch = time.time() + expires_in

    def get_access_token(self) -> str:
        if self._needs_refresh():
            self._fetch_token()
        assert self._access_token is not None
        return self._access_token


_token_manager = EntraTokenManager()


def get_access_token() -> str:
    return _token_manager.get_access_token()


def get_connection():
    Config.validate()

    server_hostname = (
        Config.DATABRICKS_HOST
        .replace("https://", "")
        .replace("http://", "")
        .strip()
        .rstrip("/")
    )

    access_token = get_access_token()

    return sql.connect(
        server_hostname=server_hostname,
        http_path=Config.DATABRICKS_HTTP_PATH,
        access_token=access_token,
    )


def run_query(query: str) -> pd.DataFrame:
    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]
    return pd.DataFrame(rows, columns=columns)


def sql_quote(value: str) -> str:
    if value is None:
        return "NULL"
    return "'" + str(value).replace("'", "''") + "'"
