AZURE_CLIENT_ID=<user-assigned-managed-identity-client-id>

KEY_VAULT_URL=https://<your-keyvault>.vault.azure.net/

KV_GRAPH_CLIENT_ID_SECRET_NAME=graph-client-id
KV_GRAPH_CLIENT_SECRET_SECRET_NAME=graph-client-secret
KV_GRAPH_TENANT_ID_SECRET_NAME=graph-tenant-id

MAX_WORKERS=4
MAX_RETRIES=6
REQUEST_TIMEOUT_SECONDS=120