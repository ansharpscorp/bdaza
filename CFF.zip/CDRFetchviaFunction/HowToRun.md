curl -X POST "https://<function-app-name>.azurewebsites.net/api/run-cdr-backfill?code=<function-key>" \
  -H "Content-Type: application/json" \
  -d "{\"targetDate\":\"2026-05-01\",\"startHour\":0,\"endHour\":24}"

  curl -X POST "https://<function-app-name>.azurewebsites.net/api/run-cdr-backfill?code=<function-key>" \
  -H "Content-Type: application/json" \
  -d "{\"targetDate\":\"2026-05-01\",\"startHour\":0,\"endHour\":1}"