import os
import time
import json
import random
import logging
from datetime import datetime, timedelta, timezone
from urllib.parse import quote
from concurrent.futures import ThreadPoolExecutor, as_completed

import azure.functions as func
import requests
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient


app = func.FunctionApp()

GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"
GRAPH_SCOPE = "https://graph.microsoft.com/.default"

MAX_WORKERS = int(os.getenv("MAX_WORKERS", "4"))
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "6"))
REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT_SECONDS", "120"))


def setting(name: str) -> str:
    value = os.getenv(name)

    if not value:
        raise ValueError(f"Missing app setting: {name}")

    return value


def get_graph_secrets():
    credential = ManagedIdentityCredential(
        client_id=setting("AZURE_CLIENT_ID")
    )

    secret_client = SecretClient(
        vault_url=setting("KEY_VAULT_URL"),
        credential=credential
    )

    graph_client_id = secret_client.get_secret(
        setting("KV_GRAPH_CLIENT_ID_SECRET_NAME")
    ).value

    graph_client_secret = secret_client.get_secret(
        setting("KV_GRAPH_CLIENT_SECRET_SECRET_NAME")
    ).value

    graph_tenant_id = secret_client.get_secret(
        setting("KV_GRAPH_TENANT_ID_SECRET_NAME")
    ).value

    return graph_client_id, graph_client_secret, graph_tenant_id


def sleep_before_retry(response, attempt: int):
    retry_after = response.headers.get("Retry-After")

    if retry_after:
        delay = int(retry_after)
    else:
        delay = min(60, (2 ** attempt) + random.uniform(0, 2))

    logging.warning(
        "Retryable error | Status=%s | Attempt=%s | Delay=%.1fs",
        response.status_code,
        attempt + 1,
        delay
    )

    time.sleep(delay)


def post_with_retry(url: str, data: dict, headers: dict | None = None):
    for attempt in range(MAX_RETRIES):

        response = requests.post(
            url,
            data=data,
            headers=headers,
            timeout=REQUEST_TIMEOUT
        )

        if response.status_code in (200, 201):
            return response

        if response.status_code in (429, 500, 502, 503, 504):
            sleep_before_retry(response, attempt)
            continue

        logging.error(
            "POST failed | Status=%s | Body=%s",
            response.status_code,
            response.text
        )

        response.raise_for_status()

    raise Exception(f"POST failed after {MAX_RETRIES} retries")


def get_with_retry(url: str, headers: dict):
    for attempt in range(MAX_RETRIES):

        response = requests.get(
            url,
            headers=headers,
            timeout=REQUEST_TIMEOUT
        )

        if response.status_code in (200, 201):
            return response

        if response.status_code in (429, 500, 502, 503, 504):
            sleep_before_retry(response, attempt)
            continue

        logging.error(
            "GET failed | Status=%s | Body=%s",
            response.status_code,
            response.text
        )

        response.raise_for_status()

    raise Exception(f"GET failed after {MAX_RETRIES} retries")


def get_graph_token(client_id: str, client_secret: str, tenant_id: str) -> str:

    token_url = (
        f"https://login.microsoftonline.com/"
        f"{tenant_id}/oauth2/v2.0/token"
    )

    payload = {
        "client_id": client_id,
        "client_secret": client_secret,
        "scope": GRAPH_SCOPE,
        "grant_type": "client_credentials"
    }

    response = post_with_retry(token_url, data=payload)

    return response.json()["access_token"]


def build_intervals(target_date: str, start_hour: int, end_hour: int):

    base = datetime.strptime(
        target_date,
        "%Y-%m-%d"
    ).replace(tzinfo=timezone.utc)

    range_start = base + timedelta(hours=start_hour)
    range_end = base + timedelta(hours=end_hour)

    intervals = []

    current = range_start

    while current < range_end:

        interval_end = min(
            current + timedelta(minutes=15),
            range_end
        )

        intervals.append((current, interval_end))

        current = interval_end

    return intervals


def build_callrecords_url(start_utc: datetime, end_utc: datetime) -> str:

    start_iso = start_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    end_iso = end_utc.strftime("%Y-%m-%dT%H:%M:%SZ")

    filter_text = (
        f"startDateTime ge {start_iso} "
        f"and startDateTime lt {end_iso}"
    )

    encoded_filter = quote(filter_text, safe="")

    return (
        f"{GRAPH_BASE_URL}/communications/callRecords"
        f"?$filter={encoded_filter}"
    )


def fetch_interval(
    access_token: str,
    start_utc: datetime,
    end_utc: datetime
) -> dict:

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json"
    }

    url = build_callrecords_url(start_utc, end_utc)

    total_count = 0
    page_count = 0

    while url:

        response = get_with_retry(url, headers)

        data = response.json()

        records = data.get("value", [])

        total_count += len(records)

        page_count += 1

        url = data.get("@odata.nextLink")

    return {
        "start": start_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "end": end_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "count": total_count,
        "pages": page_count
    }


def process_cdr_day(
    target_date: str,
    start_hour: int,
    end_hour: int
) -> dict:

    intervals = build_intervals(
        target_date,
        start_hour,
        end_hour
    )

    logging.info(
        "CDR Run Started | Date=%s | StartHour=%s "
        "| EndHour=%s | Intervals=%s | Workers=%s",
        target_date,
        start_hour,
        end_hour,
        len(intervals),
        MAX_WORKERS
    )

    graph_client_id, graph_client_secret, graph_tenant_id = (
        get_graph_secrets()
    )

    access_token = get_graph_token(
        graph_client_id,
        graph_client_secret,
        graph_tenant_id
    )

    total_records = 0
    success_count = 0
    failed_count = 0

    results = []

    with ThreadPoolExecutor(
        max_workers=MAX_WORKERS
    ) as executor:

        future_map = {
            executor.submit(
                fetch_interval,
                access_token,
                start,
                end
            ): (start, end)
            for start, end in intervals
        }

        for future in as_completed(future_map):

            start, end = future_map[future]

            try:
                result = future.result()

                results.append(result)

                total_records += result["count"]

                success_count += 1

                logging.info(
                    "Interval: %s to %s | Found=%s "
                    "| Pages=%s | Status=Success",
                    result["start"],
                    result["end"],
                    result["count"],
                    result["pages"]
                )

            except Exception as ex:

                failed_count += 1

                logging.exception(
                    "Interval: %s to %s | Status=Failed | Error=%s",
                    start.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    end.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    str(ex)
                )

    summary = {
        "targetDate": target_date,
        "startHour": start_hour,
        "endHour": end_hour,
        "totalIntervals": len(intervals),
        "successIntervals": success_count,
        "failedIntervals": failed_count,
        "totalCallRecordsFound": total_records
    }

    logging.info(
        "CDR Run Completed | Summary=%s",
        json.dumps(summary)
    )

    if failed_count > 0:
        raise Exception(
            f"{failed_count} interval(s) failed."
        )

    return summary


@app.route(
    route="run-cdr-backfill",
    methods=["POST"],
    auth_level=func.AuthLevel.FUNCTION
)
def run_cdr_backfill(
    req: func.HttpRequest
) -> func.HttpResponse:

    try:

        body = req.get_json()

        target_date = body.get("targetDate")

        start_hour = int(
            body.get("startHour", 0)
        )

        end_hour = int(
            body.get("endHour", 24)
        )

        if not target_date:

            return func.HttpResponse(
                "Missing required field: targetDate",
                status_code=400
            )

        if (
            start_hour < 0
            or end_hour > 24
            or start_hour >= end_hour
        ):

            return func.HttpResponse(
                (
                    "Invalid hour range. "
                    "Use startHour >= 0, "
                    "endHour <= 24, "
                    "startHour < endHour."
                ),
                status_code=400
            )

        summary = process_cdr_day(
            target_date,
            start_hour,
            end_hour
        )

        return func.HttpResponse(
            json.dumps(summary, indent=2),
            status_code=200,
            mimetype="application/json"
        )

    except Exception as ex:

        logging.exception(
            "HTTP-triggered CDR run failed: %s",
            str(ex)
        )

        return func.HttpResponse(
            f"Failed: {str(ex)}",
            status_code=500
        )