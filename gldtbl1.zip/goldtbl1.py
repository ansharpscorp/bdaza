# ==========================================================
# STEP 1 (PRODUCTION): Incremental build with MERGE + Watermark
# Creates/updates:
#   default.tblGold_EndpointFact
#   default.tblGold_EndpointFact_Hotline
# Tracks watermark in:
#   default.tblGold_LoadTracker
#
# Rules:
# - session_category = TeamsHotline if Is_Call_Queue_Involved OR Is_Auto_Attendant_Involved
# - Hotline split is CONFERENCE-LEVEL (any row in Conference_Id => hotline => whole conference in hotline table)
# - Receiver attribution:
#     Conf      => receiver_side = SECOND (force user side; avoid server ownership)
#     P2P:
#        First-to-Second => receiver_side = SECOND
#        Second-to-First => receiver_side = FIRST
# - bucket_end_time based on End_Time (Zulu). start_time fallback: Start_Time null => End_Time
# - Date column is string yyyy-MM-dd and used for partitioning + slicing (not for watermark)
# ==========================================================

from pyspark.sql import functions as F
from pyspark.sql.types import StringType, TimestampType
from delta.tables import DeltaTable
import hashlib
import datetime

# ---------------- CONFIG ----------------
SRC_TABLE = "default.CQDTable"  # <-- change if needed

DB = "default"
TBL_NORMAL  = f"{DB}.tblGold_EndpointFact"
TBL_HOTLINE = f"{DB}.tblGold_EndpointFact_Hotline"
TBL_TRACKER = f"{DB}.tblGold_LoadTracker"

BUCKET_MINUTES = 5

# Safety buffer: re-read last N minutes to catch late arrivals / updates (idempotent merge will dedup)
LATE_ARRIVAL_BUFFER_MIN = 30

# ---------------- HELPERS ----------------
def bucket_end(ts_col, minutes:int):
    return F.from_unixtime(
        (F.unix_timestamp(ts_col) / (minutes*60)).cast("bigint") * (minutes*60)
    ).cast("timestamp")

def sha1_id(*parts):
    s = "|".join("" if p is None else str(p) for p in parts)
    return hashlib.sha1(s.encode("utf-8")).hexdigest()

sha1_udf = F.udf(lambda *args: sha1_id(*args), StringType())

def table_exists(full_name: str) -> bool:
    return spark._jsparkSession.catalog().tableExists(full_name)

# ---------------- WATERMARK TABLE ----------------
def ensure_tracker():
    if not table_exists(TBL_TRACKER):
        spark.sql(f"""
        CREATE TABLE {TBL_TRACKER} (
            table_name STRING,
            last_processed_end_time TIMESTAMP,
            updated_at_utc TIMESTAMP
        )
        USING DELTA
        """)
        # init rows for both outputs
        init = spark.createDataFrame(
            [("tblGold_EndpointFact", None, None),
             ("tblGold_EndpointFact_Hotline", None, None)],
            "table_name string, last_processed_end_time timestamp, updated_at_utc timestamp"
        )
        init.write.format("delta").mode("append").saveAsTable(TBL_TRACKER)

def get_watermark(table_short_name: str):
    ensure_tracker()
    df = spark.table(TBL_TRACKER).where(F.col("table_name") == table_short_name)
    row = df.select("last_processed_end_time").head()
    return row["last_processed_end_time"] if row else None

def set_watermark(table_short_name: str, new_wm):
    ensure_tracker()
    # Merge update single row
    src = spark.createDataFrame(
        [(table_short_name, new_wm, datetime.datetime.utcnow())],
        "table_name string, last_processed_end_time timestamp, updated_at_utc timestamp"
    )
    dt = DeltaTable.forName(spark, TBL_TRACKER)
    (dt.alias("t")
      .merge(src.alias("s"), "t.table_name = s.table_name")
      .whenMatchedUpdate(set={
          "last_processed_end_time": "s.last_processed_end_time",
          "updated_at_utc": "s.updated_at_utc"
      })
      .whenNotMatchedInsert(values={
          "table_name": "s.table_name",
          "last_processed_end_time": "s.last_processed_end_time",
          "updated_at_utc": "s.updated_at_utc"
      })
      .execute()
    )

# ---------------- TARGET TABLE DDL ----------------
def ensure_target_tables():
    # Create empty tables with schema if not exist (partition by date string)
    if not table_exists(TBL_NORMAL):
        spark.sql(f"""
        CREATE TABLE {TBL_NORMAL} (
            endpoint_fact_id STRING,
            date STRING,
            start_time TIMESTAMP,
            end_time TIMESTAMP,
            bucket_end_time TIMESTAMP,

            conference_id STRING,
            session_id STRING,
            session_type STRING,         -- P2P / Conf
            session_type_raw STRING,     -- original Session_Type
            stream_direction STRING,
            media_type STRING,
            total_stream_count BIGINT,

            receiver_side STRING,        -- FIRST / SECOND
            receiver_user_type STRING,
            receiver_upn STRING,
            receiver_phone_number STRING,
            receiver_subnet STRING,
            receiver_reflexive_ip STRING,
            receiver_network_connection_detail STRING,
            receiver_wifi_band STRING,
            receiver_identity STRING,

            avg_jitter DOUBLE,
            avg_jitter_max DOUBLE,
            avg_round_trip DOUBLE,
            avg_round_trip_max DOUBLE,
            avg_packet_loss_rate DOUBLE,
            avg_packet_loss_rate_max DOUBLE,
            poor INT,
            poor_reason STRING,

            inserted_at_utc TIMESTAMP,
            updated_at_utc TIMESTAMP
        )
        USING DELTA
        PARTITIONED BY (date)
        """)
    if not table_exists(TBL_HOTLINE):
        spark.sql(f"""
        CREATE TABLE {TBL_HOTLINE} (
            endpoint_fact_id STRING,
            date STRING,
            start_time TIMESTAMP,
            end_time TIMESTAMP,
            bucket_end_time TIMESTAMP,

            conference_id STRING,
            session_id STRING,
            session_type STRING,         -- TeamsHotline
            session_type_raw STRING,     -- original Session_Type (P2P/Conf etc.)
            stream_direction STRING,
            media_type STRING,
            total_stream_count BIGINT,

            receiver_side STRING,        -- FIRST / SECOND (Conf forced SECOND)
            receiver_user_type STRING,
            receiver_upn STRING,
            receiver_phone_number STRING,
            receiver_subnet STRING,
            receiver_reflexive_ip STRING,
            receiver_network_connection_detail STRING,
            receiver_wifi_band STRING,
            receiver_identity STRING,

            avg_jitter DOUBLE,
            avg_jitter_max DOUBLE,
            avg_round_trip DOUBLE,
            avg_round_trip_max DOUBLE,
            avg_packet_loss_rate DOUBLE,
            avg_packet_loss_rate_max DOUBLE,
            poor INT,
            poor_reason STRING,

            inserted_at_utc TIMESTAMP,
            updated_at_utc TIMESTAMP
        )
        USING DELTA
        PARTITIONED BY (date)
        """)

# ---------------- BUILD ENDPOINT FACT DF ----------------
def build_endpoint(df, output_session_type_value: str):
    """
    df must already be filtered to the correct conference set (normal or hotline).
    output_session_type_value: "P2P/Conf" passthrough for normal, or "TeamsHotline" for hotline.
    """
    # Receiver logic with Conf override (server avoidance)
    df = (df
        .withColumn(
            "receiver_side",
            F.when(F.col("Session_Type") == "Conf", F.lit("SECOND"))
             .when(F.col("Stream_Direction") == "First-to-Second", F.lit("SECOND"))
             .when(F.col("Stream_Direction") == "Second-to-First", F.lit("FIRST"))
             .otherwise(F.lit(None))
        )
        .where(F.col("receiver_side").isNotNull())
    )

    # session_type for output
    if output_session_type_value == "TeamsHotline":
        session_type_col = F.lit("TeamsHotline")
    else:
        # normal: keep P2P / Conf as derived from Session_Type
        session_type_col = F.col("Session_Type")

    out = (df.select(
            # keys/time
            F.col("Date").alias("date"),
            "start_time",
            "end_time",
            "bucket_end_time",

            F.col("Conference_Id").alias("conference_id"),
            F.col("Session_Id").alias("session_id"),
            session_type_col.alias("session_type"),
            F.col("Session_Type").alias("session_type_raw"),
            F.col("Stream_Direction").alias("stream_direction"),
            F.col("Media_Type").alias("media_type"),
            F.col("Total_Stream_Count").cast("bigint").alias("total_stream_count"),

            "receiver_side",

            # receiver endpoint attributes
            F.when(F.col("receiver_side")=="FIRST", F.col("First_UserType"))
             .otherwise(F.col("Second_UserType")).alias("receiver_user_type"),

            F.when(F.col("receiver_side")=="FIRST", F.col("First_UPN"))
             .otherwise(F.col("Second_UPN")).alias("receiver_upn"),

            F.when(F.col("receiver_side")=="FIRST", F.col("First_Phone_Number"))
             .otherwise(F.col("Second_Phone_Number")).alias("receiver_phone_number"),

            F.when(F.col("receiver_side")=="FIRST", F.col("First_Subnet"))
             .otherwise(F.col("Second_Subnet")).alias("receiver_subnet"),

            F.when(F.col("receiver_side")=="FIRST", F.col("First_Reflexive_Local_IP_Network"))
             .otherwise(F.col("Second_Reflexive_Local_IP_Network")).alias("receiver_reflexive_ip"),

            F.when(F.col("receiver_side")=="FIRST", F.col("First_Network_Connection_Detail"))
             .otherwise(F.col("Second_Network_Connection_Detail")).alias("receiver_network_connection_detail"),

            F.when(F.col("receiver_side")=="FIRST", F.lit(None).cast("string"))
             .otherwise(F.col("Second_Wifi_Band")).alias("receiver_wifi_band"),

            # stream metrics (direction-specific rows)
            F.col("Avg_Jitter").cast("double").alias("avg_jitter"),
            F.col("Avg_Jitter_Max").cast("double").alias("avg_jitter_max"),

            (F.col("Avg_Round_Trip").cast("double").alias("avg_round_trip")
                if "Avg_Round_Trip" in df.columns else F.lit(None).cast("double").alias("avg_round_trip")),

            (F.col("Avg_Round_Trip_Max").cast("double").alias("avg_round_trip_max")
                if "Avg_Round_Trip_Max" in df.columns else F.lit(None).cast("double").alias("avg_round_trip_max")),

            (F.col("Avg_Packet_Loss_Rate").cast("double").alias("avg_packet_loss_rate")
                if "Avg_Packet_Loss_Rate" in df.columns else F.lit(None).cast("double").alias("avg_packet_loss_rate")),

            (F.col("Avg_Packet_Loss_Rate_Max").cast("double").alias("avg_packet_loss_rate_max")
                if "Avg_Packet_Loss_Rate_Max" in df.columns else F.lit(None).cast("double").alias("avg_packet_loss_rate_max")),

            (F.col("Poor").cast("int").alias("poor")
                if "Poor" in df.columns else F.lit(None).cast("int").alias("poor")),

            (F.col("Poor_Reason").alias("poor_reason")
                if "Poor_Reason" in df.columns else F.lit(None).cast("string").alias("poor_reason")),
        )
        .withColumn("receiver_identity", F.coalesce(F.col("receiver_upn"), F.col("receiver_phone_number")))
    )

    # Stable ID for MERGE (idempotent)
    out = out.withColumn(
        "endpoint_fact_id",
        sha1_udf(
            F.col("bucket_end_time").cast("string"),
            F.col("session_id"),
            F.col("media_type"),
            F.col("stream_direction"),
            F.col("receiver_side"),
            F.col("receiver_subnet"),
            F.col("receiver_identity")
        )
    )

    nowts = F.current_timestamp()
    out = (out
        .withColumn("inserted_at_utc", nowts)
        .withColumn("updated_at_utc", nowts)
    )

    return out

# ---------------- MERGE UPSERT ----------------
def merge_into(target_table: str, df):
    dt = DeltaTable.forName(spark, target_table)
    # Only update mutable columns; keep inserted_at_utc from target if you prefer.
    update_cols = [c for c in df.columns if c != "endpoint_fact_id"]
    set_map = {c: f"s.{c}" for c in update_cols}
    insert_map = {c: f"s.{c}" for c in df.columns}

    (dt.alias("t")
      .merge(df.alias("s"), "t.endpoint_fact_id = s.endpoint_fact_id")
      .whenMatchedUpdate(set=set_map)
      .whenNotMatchedInsert(values=insert_map)
      .execute()
    )

# ==========================================================
# RUN
# ==========================================================
ensure_target_tables()
ensure_tracker()

# Watermark is shared per pipeline step (we use the same watermark for both normal/hotline)
# You can maintain separate watermarks if you prefer; usually not necessary because both come from same source.
wm = get_watermark("tblGold_EndpointFact")
if wm is None:
    # first run: choose a safe starting point (e.g., last 1 day). Adjust as needed.
    wm = datetime.datetime.utcnow() - datetime.timedelta(days=1)

# Apply late-arrival buffer
wm_with_buffer = wm - datetime.timedelta(minutes=LATE_ARRIVAL_BUFFER_MIN)

# Load incremental slice from source based on End_Time (Zulu)
cqd = (spark.table(SRC_TABLE)
  # Parse Zulu timestamps; to_timestamp handles ISO8601 with Z in Spark
  .withColumn("end_time", F.to_timestamp("End_Time"))
  .withColumn("start_time_raw", F.to_timestamp("Start_Time"))
  .withColumn("start_time", F.coalesce(F.col("start_time_raw"), F.col("end_time")))
  .withColumn("bucket_end_time", bucket_end(F.col("end_time"), BUCKET_MINUTES))
  .where(F.col("end_time") > F.lit(wm_with_buffer).cast("timestamp"))
)

# Session category flag (row-level)
cqd = cqd.withColumn(
    "session_category_row",
    F.when((F.col("Is_Call_Queue_Involved") == True) | (F.col("Is_Auto_Attendant_Involved") == True), F.lit("TeamsHotline"))
     .otherwise(F.col("Session_Type"))
)

# Conference-level hotline list
hotline_conf = (cqd
    .where(F.col("session_category_row") == "TeamsHotline")
    .select("Conference_Id")
    .distinct()
)

cqd_normal  = cqd.join(hotline_conf, on="Conference_Id", how="left_anti")
cqd_hotline = cqd.join(hotline_conf, on="Conference_Id", how="inner")

# Build endpoint fact DFs
df_normal  = build_endpoint(cqd_normal,  output_session_type_value="NORMAL")        # keeps P2P/Conf via Session_Type
df_hotline = build_endpoint(cqd_hotline, output_session_type_value="TeamsHotline")  # forces TeamsHotline

# MERGE into targets
merge_into(TBL_NORMAL, df_normal)
merge_into(TBL_HOTLINE, df_hotline)

# Advance watermark: use max end_time processed in this run (from *source slice*)
max_end = cqd.agg(F.max("end_time").alias("mx")).collect()[0]["mx"]
if max_end is not None and max_end > wm:
    set_watermark("tblGold_EndpointFact", max_end)
    set_watermark("tblGold_EndpointFact_Hotline", max_end)

# ---------------- QUICK VALIDATION OUTPUTS ----------------
print("Watermark before:", wm)
print("Watermark buffer :", wm_with_buffer)
print("Watermark after :", max_end)

print("Normal new rows processed :", df_normal.count())
print("Hotline new rows processed:", df_hotline.count())

spark.sql(f"""
SELECT session_type, receiver_side, COUNT(*) AS c
FROM {TBL_NORMAL}
GROUP BY session_type, receiver_side
ORDER BY session_type, receiver_side
""").show(truncate=False)

spark.sql(f"""
SELECT session_type, receiver_side, COUNT(*) AS c
FROM {TBL_HOTLINE}
GROUP BY session_type, receiver_side
ORDER BY session_type, receiver_side
""").show(truncate=False)
