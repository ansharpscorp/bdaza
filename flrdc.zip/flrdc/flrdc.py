from __future__ import annotations

import json
import csv
from pathlib import Path
from typing import Any, Dict, Iterable, List, Union


JsonType = Union[Dict[str, Any], List[Any], str, int, float, bool, None]


def flatten_json(
    data: JsonType,
    parent_key: str = "",
    sep: str = "_",
) -> Dict[str, Any]:
    """
    Recursively flatten a JSON object into a single-level dictionary.

    Rules:
    - dict keys are joined with `sep`
    - list items are flattened using their index
      Example:
        sessions[0].id -> sessions_0_id
    - scalar values are stored directly
    - empty dict/list are preserved as JSON strings to avoid silent loss

    This creates one wide row per source JSON file.
    """
    items: Dict[str, Any] = {}

    if isinstance(data, dict):
        if not data:
            if parent_key:
                items[parent_key] = "{}"
            return items

        for key, value in data.items():
            new_key = f"{parent_key}{sep}{key}" if parent_key else str(key)
            items.update(flatten_json(value, new_key, sep=sep))

    elif isinstance(data, list):
        if not data:
            if parent_key:
                items[parent_key] = "[]"
            return items

        for index, value in enumerate(data):
            new_key = f"{parent_key}{sep}{index}" if parent_key else str(index)
            items.update(flatten_json(value, new_key, sep=sep))

    else:
        items[parent_key] = data

    return items


def load_json(path: Path) -> JsonType:
    """
    Load JSON from disk with UTF-8 encoding.
    """
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_single_row_csv(row: Dict[str, Any], output_path: Path) -> None:
    """
    Write a single flattened dictionary as a one-row CSV.
    """
    fieldnames = list(row.keys())
    with output_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerow(row)


def write_multi_row_csv(rows: List[Dict[str, Any]], output_path: Path) -> None:
    """
    Write multiple flattened dictionaries to a CSV using the union of all keys.
    """
    all_fields = sorted({key for row in rows for key in row.keys()})
    with output_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=all_fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def main() -> None:
    """
    Expected local folder structure:

    ./input/
        peerToPeer.json
        groupCall.json

    Output:
    ./output/
        peer_to_peer_flat.csv
        group_call_flat.csv
        combined_flat.csv
    """
    base_dir = Path.cwd()
    input_dir = base_dir / "input"
    output_dir = base_dir / "output"
    output_dir.mkdir(parents=True, exist_ok=True)

    input_files = {
        "peer_to_peer": input_dir / "peerToPeer.json",
        "group_call": input_dir / "groupCall.json",
    }

    combined_rows: List[Dict[str, Any]] = []

    for label, json_path in input_files.items():
        if not json_path.exists():
            raise FileNotFoundError(f"Missing input file: {json_path}")

        raw_json = load_json(json_path)
        flat_row = flatten_json(raw_json)

        # Add metadata columns for traceability
        flat_row["source_label"] = label
        flat_row["source_file"] = json_path.name

        output_csv = output_dir / f"{label}_flat.csv"
        write_single_row_csv(flat_row, output_csv)

        combined_rows.append(flat_row)

        print(f"Wrote: {output_csv}")

    combined_csv = output_dir / "combined_flat.csv"
    write_multi_row_csv(combined_rows, combined_csv)
    print(f"Wrote: {combined_csv}")


if __name__ == "__main__":
    main()