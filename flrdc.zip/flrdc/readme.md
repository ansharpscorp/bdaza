your_folder/
├── input/
│   ├── peerToPeer.json
│   └── groupCall.json
├── flatten_cdr.py
└── output/