from __future__ import annotations

import json
import csv
from pathlib import Path
from typing import Any, Dict, List


def json_scalar(value: Any) -> Any:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return value


def flatten_dict(data: dict, prefix: str = "") -> Dict[str, Any]:
    result = {}

    for k, v in data.items():
        col = f"{prefix}_{k}" if prefix else k

        if isinstance(v, dict):
            result.update(flatten_dict(v, col))
        elif isinstance(v, list):
            result[col] = json_scalar(v)
        else:
            result[col] = v

    return result


def build_stream_rows(call_data: dict, file_name: str) -> List[Dict[str, Any]]:
    rows = []

    # -------------------------
    # CALL LEVEL
    # -------------------------
    call_base = {}

    for k, v in call_data.items():
        if k == "sessions":
            continue
        elif isinstance(v, dict):
            call_base.update(flatten_dict(v, k))
        elif isinstance(v, list):
            call_base[k] = json_scalar(v)
        else:
            call_base[k] = v

    call_base["call_id_file"] = file_name

    sessions = call_data.get("sessions", []) or []

    for session in sessions:
        session_base = call_base.copy()

        for k, v in session.items():
            if k == "segments":
                continue
            elif isinstance(v, dict):
                session_base.update(flatten_dict(v, f"session_{k}"))
            elif isinstance(v, list):
                session_base[f"session_{k}"] = json_scalar(v)
            else:
                session_base[f"session_{k}"] = v

        segments = session.get("segments", []) or []

        for segment in segments:
            segment_base = session_base.copy()

            for k, v in segment.items():
                if k == "media":
                    continue
                elif isinstance(v, dict):
                    segment_base.update(flatten_dict(v, f"segment_{k}"))
                elif isinstance(v, list):
                    segment_base[f"segment_{k}"] = json_scalar(v)
                else:
                    segment_base[f"segment_{k}"] = v

            media_list = segment.get("media", []) or []

            for media in media_list:
                media_base = segment_base.copy()

                for k, v in media.items():
                    if k == "streams":
                        continue
                    elif isinstance(v, dict):
                        media_base.update(flatten_dict(v, f"media_{k}"))
                    elif isinstance(v, list):
                        media_base[f"media_{k}"] = json_scalar(v)
                    else:
                        media_base[f"media_{k}"] = v

                streams = media.get("streams", []) or []

                for stream in streams:
                    row = media_base.copy()

                    for k, v in stream.items():
                        if isinstance(v, dict):
                            row.update(flatten_dict(v, f"stream_{k}"))
                        elif isinstance(v, list):
                            row[f"stream_{k}"] = json_scalar(v)
                        else:
                            row[f"stream_{k}"] = v

                    rows.append(row)

    return rows


def write_csv(rows: List[Dict[str, Any]], path: Path):
    if not rows:
        return

    cols = sorted({k for r in rows for k in r.keys()})

    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=cols)
        writer.writeheader()
        writer.writerows(rows)


def main():
    base = Path.cwd()
    input_dir = base / "input"
    output_dir = base / "output"
    output_dir.mkdir(exist_ok=True)

    combined_rows = []

    json_files = list(input_dir.glob("*.json"))

    if not json_files:
        raise Exception("No JSON files found in input folder")

    for file in json_files:
        with file.open("r", encoding="utf-8") as f:
            data = json.load(f)

        rows = build_stream_rows(data, file.name)

        out_file = output_dir / f"{file.stem}_streams.csv"
        write_csv(rows, out_file)

        print(f"{file.name} → {len(rows)} rows")

        combined_rows.extend(rows)

    combined_file = output_dir / "all_calls_streams.csv"
    write_csv(combined_rows, combined_file)

    print(f"\nTotal rows: {len(combined_rows)}")
    print(f"Combined file: {combined_file}")


if __name__ == "__main__":
    main()