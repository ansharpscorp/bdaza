import json
import os
import sys
import time
import uuid
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from azure.identity import ClientSecretCredential
from azure.storage.blob import BlobServiceClient
from azure.eventhub import EventHubConsumerClient


class TestState:
    def __init__(self) -> None:
        self.done = threading.Event()
        self.found = False
        self.error: Optional[str] = None
        self.messages_seen = 0

        self.match_partition_id: Optional[str] = None
        self.match_sequence_number: Optional[int] = None
        self.match_offset: Optional[str] = None
        self.match_enqueued_time: Optional[str] = None

        self.match_event: Optional[Dict[str, Any]] = None
        self.match_raw_body: Optional[str] = None


def load_config(config_path: str) -> Dict[str, Any]:
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def ensure_file_exists(path: str) -> None:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Local file not found: {path}")


def build_blob_name(folder: str, local_file_path: str) -> str:
    filename = os.path.basename(local_file_path)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    unique = uuid.uuid4().hex[:10]

    folder = folder.strip("/")
    if folder:
        return f"{folder}/{ts}_{unique}_{filename}"
    return f"{ts}_{unique}_{filename}"


def normalize_body_to_text(event) -> str:
    try:
        return b"".join(event.body).decode("utf-8", errors="replace")
    except Exception:
        try:
            return str(event.body_as_str(encoding="UTF-8"))
        except Exception:
            return ""


def parse_json_safely(raw: str) -> Any:
    try:
        return json.loads(raw)
    except Exception:
        return None


def normalize_event_list(payload: Any) -> List[Dict[str, Any]]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        return [payload]
    return []


def extract_event_type(evt: Dict[str, Any]) -> Optional[str]:
    return evt.get("eventType") or evt.get("type")


def extract_blob_url(evt: Dict[str, Any]) -> Optional[str]:
    data = evt.get("data")
    if isinstance(data, dict):
        return data.get("url")
    return None


def extract_subject(evt: Dict[str, Any]) -> Optional[str]:
    return evt.get("subject")


def event_summary(evt: Dict[str, Any]) -> Dict[str, Any]:
    data = evt.get("data", {}) if isinstance(evt.get("data"), dict) else {}
    return {
        "id": evt.get("id"),
        "eventType": evt.get("eventType") or evt.get("type"),
        "topic": evt.get("topic"),
        "subject": evt.get("subject"),
        "eventTime": evt.get("eventTime") or evt.get("time"),
        "blobUrl": data.get("url"),
        "api": data.get("api"),
        "contentLength": data.get("contentLength"),
        "contentType": data.get("contentType"),
        "blobType": data.get("blobType"),
        "eTag": data.get("eTag"),
        "sequencer": data.get("sequencer"),
        "requestId": data.get("requestId"),
        "clientRequestId": data.get("clientRequestId")
    }


def create_credential(cfg: Dict[str, Any]) -> ClientSecretCredential:
    auth = cfg["auth"]
    return ClientSecretCredential(
        tenant_id=auth["tenant_id"],
        client_id=auth["client_id"],
        client_secret=auth["client_secret"]
    )


def upload_test_blob(cfg: Dict[str, Any], credential: ClientSecretCredential) -> Dict[str, str]:
    storage = cfg["storage"]
    account_url = storage["account_url"].rstrip("/")
    container = storage["container"]
    folder = storage.get("folder", "")
    local_file_path = storage["local_file_path"]

    ensure_file_exists(local_file_path)

    blob_name = build_blob_name(folder, local_file_path)
    expected_blob_url = f"{account_url}/{container}/{blob_name}"

    blob_service_client = BlobServiceClient(account_url=account_url, credential=credential)
    blob_client = blob_service_client.get_blob_client(container=container, blob=blob_name)

    with open(local_file_path, "rb") as data:
        blob_client.upload_blob(data, overwrite=False)

    return {
        "blob_name": blob_name,
        "blob_url": expected_blob_url,
        "container": container
    }


def delete_blob_if_needed(cfg: Dict[str, Any], credential: ClientSecretCredential, blob_name: str) -> None:
    if not cfg["test"].get("delete_blob_after_test", False):
        return

    storage = cfg["storage"]
    blob_service_client = BlobServiceClient(
        account_url=storage["account_url"].rstrip("/"),
        credential=credential
    )
    blob_client = blob_service_client.get_blob_client(
        container=storage["container"],
        blob=blob_name
    )
    blob_client.delete_blob()


def listen_for_blob_created(
    cfg: Dict[str, Any],
    credential: ClientSecretCredential,
    expected_blob_url: str,
    expected_blob_name: str,
    state: TestState
) -> None:
    eh = cfg["eventhub"]

    def on_event(partition_context, event) -> None:
        try:
            state.messages_seen += 1

            raw_body = normalize_body_to_text(event)
            payload = parse_json_safely(raw_body)
            events = normalize_event_list(payload)

            for evt in events:
                event_type = extract_event_type(evt)
                blob_url = extract_blob_url(evt)
                subject = extract_subject(evt) or ""

                url_match = (blob_url == expected_blob_url)
                subject_match = expected_blob_name in subject

                if event_type == "Microsoft.Storage.BlobCreated" and (url_match or subject_match):
                    state.found = True
                    state.match_event = event_summary(evt)
                    state.match_raw_body = raw_body
                    state.match_partition_id = partition_context.partition_id
                    state.match_sequence_number = event.sequence_number
                    state.match_offset = str(event.offset) if event.offset is not None else None
                    state.match_enqueued_time = (
                        event.enqueued_time.isoformat() if event.enqueued_time else None
                    )
                    state.done.set()
                    return
        except Exception as exc:
            state.error = f"Event processing error: {exc}"
            state.done.set()

    def on_error(partition_context, error) -> None:
        state.error = f"EventHub receive error: {error}"
        state.done.set()

    client = EventHubConsumerClient(
        fully_qualified_namespace=eh["fully_qualified_namespace"],
        eventhub_name=eh["eventhub_name"],
        consumer_group=eh.get("consumer_group", "$Default"),
        credential=credential
    )

    try:
        with client:
            client.receive(
                on_event=on_event,
                on_error=on_error,
                starting_position="@latest"
            )
    except Exception as exc:
        state.error = f"Listener failed to start: {exc}"
        state.done.set()


def main() -> int:
    config_path = sys.argv[1] if len(sys.argv) > 1 else "config.json"
    cfg = load_config(config_path)

    print("=== BlobCreated -> Event Grid -> Event Hub test ===")
    print(f"UTC Start Time : {now_utc()}")

    credential = create_credential(cfg)

    storage = cfg["storage"]
    eh = cfg["eventhub"]
    test_cfg = cfg["test"]

    print(f"Storage Account : {storage['account_url']}")
    print(f"Container       : {storage['container']}")
    print(f"Folder          : {storage.get('folder', '')}")
    print(f"Local File      : {storage['local_file_path']}")
    print(f"EventHub NS     : {eh['fully_qualified_namespace']}")
    print(f"EventHub Name   : {eh['eventhub_name']}")
    print(f"Consumer Group  : {eh.get('consumer_group', '$Default')}")
    print()

    state = TestState()

    placeholder_blob_name = build_blob_name(storage.get("folder", ""), storage["local_file_path"])
    expected_blob_url = f"{storage['account_url'].rstrip('/')}/{storage['container']}/{placeholder_blob_name}"

    # Start listener first
    print("Starting Event Hub listener...")
    listener_thread = threading.Thread(
        target=listen_for_blob_created,
        args=(cfg, credential, expected_blob_url, placeholder_blob_name, state),
        daemon=True
    )
    listener_thread.start()

    delay = int(test_cfg.get("listener_start_delay_seconds", 5))
    time.sleep(delay)

    # Upload actual blob
    try:
        print("Uploading test blob...")
        upload_start = time.time()
        upload_info = upload_test_blob(cfg, credential)
        actual_blob_name = upload_info["blob_name"]
        actual_blob_url = upload_info["blob_url"]
    except Exception as exc:
        print(f"ERROR: Upload failed: {exc}")
        return 1

    print(f"Uploaded Blob Name : {actual_blob_name}")
    print(f"Uploaded Blob URL  : {actual_blob_url}")
    print()

    # Restart listener with exact blob details if needed
    if actual_blob_name != placeholder_blob_name:
        state = TestState()
        print("Restarting listener with exact blob path...")
        listener_thread = threading.Thread(
            target=listen_for_blob_created,
            args=(cfg, credential, actual_blob_url, actual_blob_name, state),
            daemon=True
        )
        listener_thread.start()

    timeout_seconds = int(test_cfg.get("wait_timeout_seconds", 180))
    print(f"Waiting up to {timeout_seconds} seconds for matching BlobCreated event...")

    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        if state.done.wait(timeout=1):
            break

    elapsed = time.time() - upload_start

    print()
    print("=== Result ===")

    if state.error:
        print(f"Status              : ERROR")
        print(f"Error               : {state.error}")
        return 1

    if not state.found:
        print("Status              : NOT RECEIVED")
        print(f"Elapsed Seconds     : {elapsed:.2f}")
        print(f"Messages Seen       : {state.messages_seen}")
        print(f"Blob Name           : {actual_blob_name}")
        print(f"Blob URL            : {actual_blob_url}")
        print()
        print("Likely reasons:")
        print("- Event subscription is missing or targets a different Event Hub")
        print("- Included event type does not include Microsoft.Storage.BlobCreated")
        print("- Subject filters exclude this container/folder/blob")
        print("- Service principal lacks Blob Data Contributor / Event Hubs Data Receiver permissions")
        print("- Event Grid delivery to Event Hub is failing")
        return 2

    print("Status              : RECEIVED")
    print(f"Elapsed Seconds     : {elapsed:.2f}")
    print(f"Messages Seen       : {state.messages_seen}")
    print(f"Partition ID        : {state.match_partition_id}")
    print(f"Sequence Number     : {state.match_sequence_number}")
    print(f"Offset              : {state.match_offset}")
    print(f"Enqueued Time (UTC) : {state.match_enqueued_time}")
    print()

    print("Matched Event Details:")
    print(json.dumps(state.match_event, indent=2, ensure_ascii=False))
    print()

    print("Raw EventHub Payload:")
    print(state.match_raw_body)

    try:
        delete_blob_if_needed(cfg, credential, actual_blob_name)
    except Exception as exc:
        print()
        print(f"Warning: blob cleanup failed: {exc}")

    return 0


if __name__ == "__main__":
    sys.exit(main())