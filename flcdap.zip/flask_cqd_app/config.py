import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key")

    # Databricks workspace connection using OAuth M2M with service principal
    DATABRICKS_HOST = os.getenv("DATABRICKS_HOST", "")
    DATABRICKS_SERVER_HOSTNAME = os.getenv("DATABRICKS_SERVER_HOSTNAME", "")
    DATABRICKS_HTTP_PATH = os.getenv("DATABRICKS_HTTP_PATH", "")
    DATABRICKS_CLIENT_ID = os.getenv("DATABRICKS_CLIENT_ID", "")
    DATABRICKS_CLIENT_SECRET = os.getenv("DATABRICKS_CLIENT_SECRET", "")

    DB_SCHEMA = os.getenv("DB_SCHEMA", "cqd_ml")

    TBL_INCIDENT = os.getenv("TBL_INCIDENT", f"{DB_SCHEMA}.cqd_incident_summaries")
    TBL_HOURLY = os.getenv("TBL_HOURLY", f"{DB_SCHEMA}.cqd_insights_hourly")
    TBL_CALL_DETAIL = os.getenv("TBL_CALL_DETAIL", f"{DB_SCHEMA}.cqd_call_details")
    TBL_CALL_SUMMARY = os.getenv("TBL_CALL_SUMMARY", f"{DB_SCHEMA}.cqd_call_summary")
    TBL_ROLLUP_SUBNET_DAY = os.getenv("TBL_ROLLUP_SUBNET_DAY", f"{DB_SCHEMA}.cqd_rollup_subnet_day")
    TBL_ROLLUP_REFIP_DAY = os.getenv("TBL_ROLLUP_REFIP_DAY", f"{DB_SCHEMA}.cqd_rollup_refip_day")

    DEFAULT_LOOKBACK_DAYS = int(os.getenv("DEFAULT_LOOKBACK_DAYS", "7"))
    MAX_TABLE_ROWS = int(os.getenv("MAX_TABLE_ROWS", "200"))

    @classmethod
    def server_hostname(cls) -> str:
        if cls.DATABRICKS_SERVER_HOSTNAME:
            return cls.DATABRICKS_SERVER_HOSTNAME
        host = cls.DATABRICKS_HOST.strip()
        if host.startswith("https://"):
            host = host[len("https://"):]
        return host.rstrip("/")
