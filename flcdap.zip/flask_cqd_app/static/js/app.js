document.addEventListener("DOMContentLoaded", function () {
  const networkTypeSelect = document.getElementById("network_type_select");
  const subnetDatalist = document.getElementById("subnet_options");

  if (networkTypeSelect && subnetDatalist) {
    networkTypeSelect.addEventListener("change", async function () {
      const networkType = this.value;
      const resp = await fetch(`/api/subnets?network_type=${encodeURIComponent(networkType)}`);
      const data = await resp.json();

      subnetDatalist.innerHTML = "";
      (data.subnets || []).forEach(subnet => {
        const option = document.createElement("option");
        option.value = subnet;
        subnetDatalist.appendChild(option);
      });
    });
  }
});
