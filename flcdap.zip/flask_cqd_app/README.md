# CQD Flask App

This Flask app connects to Databricks SQL using **OAuth machine-to-machine authentication** with a Databricks service principal.

It uses:
- `DATABRICKS_HOST`
- `DATABRICKS_HTTP_PATH`
- `DATABRICKS_CLIENT_ID`
- `DATABRICKS_CLIENT_SECRET`

This follows Databricks official guidance for OAuth M2M with the Python SQL connector and unified authentication. See the Databricks SQL Connector and OAuth M2M docs. citeturn941020search0turn941020search1turn941020search2

## Pages

### 1. Dashboard
Shows:
- KPI cards
- worst actionable subnets
- region impact chart
- last 7 days trend
- last 30 days trend
- alert table with users affected and suggested owner team
- subnet drillthrough links

### 2. AI Insights
Shows:
- Evaluate / Compare mode
- network type filtering
- subnet selection with searchable list
- English query preview
- selected subnet vs peer charts
- grounded narrative summary
- evidence table

### 3. Subnet Drillthrough
Shows:
- subnet KPIs
- subnet trend
- impacted users
- calls / sessions for the subnet

## Project structure

```text
flask_cqd_app/
├── app.py
├── config.py
├── db.py
├── requirements.txt
├── .env.example
├── README.md
├── services/
│   ├── __init__.py
│   ├── dashboard_service.py
│   ├── insights_service.py
│   └── chart_service.py
├── templates/
│   ├── base.html
│   ├── dashboard.html
│   ├── subnet_detail.html
│   └── insights.html
└── static/
    ├── css/
    │   └── app.css
    └── js/
        └── app.js
```

## Setup

1. Create a Python virtual environment.
2. Install packages:

```bash
pip install -r requirements.txt
```

3. Copy `.env.example` to `.env` and fill the values.
4. Run:

```bash
python app.py
```

5. Open:

```text
http://localhost:5000
```

## Required Databricks permissions

The service principal must have:
- access to the target SQL warehouse
- access to the workspace
- permission to read the target schema and tables

Databricks documents that a service principal must be assigned to the workspace and granted access to compute such as SQL warehouses for OAuth M2M usage. citeturn941020search1turn941020search3

## Notes on authentication

The SQL connector supports OAuth machine-to-machine authentication, and Databricks shows using `databricks.sdk.core.Config` plus `credentials_provider=lambda: cfg.authenticate` for service-principal based authorization. citeturn941020search0turn941020search2
