from databricks import sql
from databricks.sdk.core import Config as DBXConfig
import pandas as pd
from config import Config


def get_connection():
    cfg = DBXConfig(
        host=Config.DATABRICKS_HOST,
        client_id=Config.DATABRICKS_CLIENT_ID,
        client_secret=Config.DATABRICKS_CLIENT_SECRET,
    )
    return sql.connect(
        server_hostname=Config.server_hostname(),
        http_path=Config.DATABRICKS_HTTP_PATH,
        credentials_provider=lambda: cfg.authenticate,
    )


def run_query(query: str) -> pd.DataFrame:
    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]
    return pd.DataFrame(rows, columns=columns)


def sql_quote(value: str) -> str:
    if value is None:
        return "NULL"
    return "'" + str(value).replace("'", "''") + "'"
