import time
from typing import Optional

import pandas as pd
import requests
from databricks import sql

from config import Config


class DatabricksTokenManager:
    def __init__(self) -> None:
        self._access_token: Optional[str] = None
        self._expires_at_epoch: float = 0.0

    def _token_url(self) -> str:
        host = Config.DATABRICKS_HOST.rstrip("/")
        return f"{host}/oidc/v1/token"

    def _needs_refresh(self) -> bool:
        # Refresh 60 seconds before actual expiry
        return (
            not self._access_token
            or time.time() >= max(0.0, self._expires_at_epoch - 60)
        )

    def _fetch_token(self) -> None:
        Config.validate()

        response = requests.post(
            self._token_url(),
            auth=(Config.DATABRICKS_CLIENT_ID, Config.DATABRICKS_CLIENT_SECRET),
            data={
                "grant_type": "client_credentials",
                "scope": "all-apis",
            },
            timeout=30,
        )
        response.raise_for_status()

        payload = response.json()
        token = payload.get("access_token")
        expires_in = int(payload.get("expires_in", 3600))

        if not token:
            raise RuntimeError("Databricks OAuth response did not include access_token.")

        self._access_token = token
        self._expires_at_epoch = time.time() + expires_in

    def get_access_token(self) -> str:
        if self._needs_refresh():
            self._fetch_token()
        assert self._access_token is not None
        return self._access_token


_token_manager = DatabricksTokenManager()


def get_connection():
    """
    Create a Databricks SQL connection using an OAuth access token
    fetched from the workspace OIDC token endpoint.
    """
    Config.validate()

    server_hostname = (
        Config.DATABRICKS_HOST
        .replace("https://", "")
        .replace("http://", "")
        .strip()
        .rstrip("/")
    )

    access_token = _token_manager.get_access_token()

    return sql.connect(
        server_hostname=server_hostname,
        http_path=Config.DATABRICKS_HTTP_PATH,
        access_token=access_token,
    )


def run_query(query: str) -> pd.DataFrame:
    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]
    return pd.DataFrame(rows, columns=columns)


def sql_quote(value: str) -> str:
    if value is None:
        return "NULL"
    return "'" + str(value).replace("'", "''") + "'"